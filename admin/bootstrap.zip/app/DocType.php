<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DocType extends Model
{
    //
}
