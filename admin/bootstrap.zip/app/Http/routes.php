<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::group(['middleware' => 'web'], function () {
    Route::get('/', ['as' => 'home', 'uses' => 'HomeController@viewHomePage']);
    Route::get('login', ['as' => 'login', 'uses' => 'UserController@viewLoginForm']);
    Route::get('forget-password', ['as' => 'forget-password', 'uses' => 'UserController@forgetPassword']);
    Route::get('logout', ['as' => 'logout',  'middleware' => 'auth', 'uses' => 'UserController@logOut']);
    Route::post('checkEmail', ['as' => 'check_email', 'uses' => 'UserController@checkEmail']);
    Route::post('resetPassword', ['as' => 'resetPassword', 'uses' => 'UserController@resetPassword']);
    Route::post('processLogin', ['as' => 'process_login', 'uses' => 'UserController@processLogin']);
    Route::post('registerUser', ['as' => 'register_user', 'uses' => 'UserController@registerUser']);
    Route::get('getUsersList/{user_type}', ['as' => 'users_list',  'middleware' => 'auth', 'uses' => 'UserController@getUsersList']);
    Route::get('deleteUser/{user_type}/{user_id}', ['as' => 'users_list',  'middleware' => 'auth', 'uses' => 'UserController@deleteUser']);
    Route::get('delete_order/{id}', ['as' => 'order_list',  'middleware' => 'auth', 'uses' => 'OrdersController@deleteOrderDetails']);
    Route::get('deleteLocation/{user_id}', ['as' => 'users_list',  'middleware' => 'auth', 'uses' => 'LocationController@deleteLocation']);
    Route::get('deleteRoute/{id}', ['as' => 'users_list',  'middleware' => 'auth', 'uses' => 'RoutesController@deleteRoute']);
    Route::get('deleteCycle/{id}', ['as' => 'users_list',  'middleware' => 'auth', 'uses' => 'LocationController@deleteCycle']);
    Route::get('getOrdersList/{order_status}', ['as' => 'users_list',  'middleware' => 'auth', 'uses' => 'OrdersController@loadOrders']);
    Route::get('getUpazilla/{id}', ['as' => 'users_list',  'middleware' => 'auth', 'uses' => 'OrdersController@getUpazilla']);
    Route::get('assignCourier/{order_id}/{courier_id}/{location_id}', ['as' => 'users_list',   'middleware' => 'auth','uses' => 'OrdersController@assignCourier']);
    Route::get('getLocationbasedCourier/{id}', ['as' => 'users_list',  'middleware' => 'auth', 'uses' => 'LocationController@getLocationbasedCourier']);
    Route::get('changeOrderStatus/{order_id}/{status}', ['as' => 'users_list',  'middleware' => 'auth', 'uses' => 'OrdersController@changeStatus']);
    Route::get('getCouriersList', ['as' => 'users_list',  'middleware' => 'auth', 'uses' => 'CourierController@loadCouriers']);
    Route::get('fetchUserDetails/{user_id}', ['as' => 'users_list',  'middleware' => 'auth', 'uses' => 'UserController@getUserDetails']);
    Route::get('fetchReceiverDetails/{user_name}', ['as' => 'users_list',  'middleware' => 'auth', 'uses' => 'UserController@fetchReceiverDetails']);
    Route::get('gehboard/orders/alltLocationsList', ['as' => 'locations_list',  'middleware' => 'auth', 'uses' => 'LocationController@loadLocations']);
    Route::get('getLocationBasedCouriersList/{loc_id}', ['as' => 'locations_list',  'middleware' => 'auth', 'uses' => 'LocationController@getLocationBasedCouriersList']);
    Route::get('roles', ['as' => 'roles_list',  'middleware' => 'auth', 'uses' => 'UserController@getRoles']);
    Route::get('view/{user_type}/{id}', ['as' => 'roles_list',  'middleware' => 'auth', 'uses' => 'UserController@viewUserDetails']);
    Route::post('roles', ['as' => 'roles_list', 'uses' => 'UserController@addRoles']);
    Route::get('permissions', ['as' => 'permissions_list',  'middleware' => 'auth', 'uses' => 'UserController@getPermissions']);
    Route::post('permissions', ['as' => 'permissions_list', 'uses' => 'UserController@addPermissions']);
    Route::post('filterSearchOrder', ['as' => 'filter_order', 'uses' => 'OrderController@filterSearchOrder']);
    Route::get('dashboard/roles', ['as' => 'roles',   'middleware' => 'auth', 'uses' => 'UserController@viewRoles']);
    Route::get('dashboard/role/{role_id}/permission', ['as' => 'assign_permission',  'middleware' => 'auth', 'uses'=>'UserController@assignPermission']);
    Route::get('dashboard', ['as' => 'dashboard', 'middleware' => 'auth',  'middleware' => 'auth', 'uses' => 'DashboardController@viewDashboard']);
    Route::get('assignPermissions/{action}/{role}/{id}', ['as' => 'assign_permissions',  'middleware' => 'auth', 'middleware' => 'auth', 'uses' => 'UserController@assignPermissionToRole']);
    Route::post('orders/add', ['as' => 'add_order', 'uses' => 'OrdersController@addOrder']);
    Route::post('location/add', ['as' => 'add_location', 'uses' => 'LocationController@addLocation']);
    Route::post('cycle/add', ['as' => 'add_location', 'uses' => 'LocationController@addCycle']);
    Route::post('location/update', ['as' => 'add_location', 'uses' => 'LocationController@updateLocation']);
    Route::post('cycle/update', ['as' => 'add_location', 'uses' => 'LocationController@updateCycle']);
    Route::post('route/update', ['as' => 'add_location', 'uses' => 'RoutesController@updateRoute']);
    Route::post('location/addCourier', ['as' => 'add_courier_to_location', 'uses' => 'LocationController@addCourierToLocation']);
    Route::post('dashboard/couriers/add', ['as' => 'add_order', 'uses' => 'CourierController@addCourier']);
    Route::get('dashboard/permissions', ['as' => 'permissions',  'middleware' => 'auth', 'uses' => 'UserController@viewPermissions']);
    Route::get('logout', ['as' => 'logout',  'middleware' => 'auth', 'uses' => 'UserController@doLogout']);
    Route::get('dashboard/{user_type}/list', ['as' => 'clients', 'middleware' => 'auth', 'uses' => 'UserController@loadUsersList']);
    Route::get('dashboard/orders/all/{order_status}', ['as' => 'orders',   'middleware' => 'auth','uses' => 'OrdersController@fetchOrdersList']);
    Route::get('dashboard/couriers/all', ['as' => 'orders',  'middleware' => 'auth', 'uses' => 'CourierController@fetchCouriersList']);
    Route::get('dashboard/locations/all', ['as' => 'orders',  'middleware' => 'auth', 'uses' => 'LocationController@fetchLocationsList']);
    Route::get('dashboard/cycles/all', ['as' => 'orders',  'middleware' => 'auth', 'uses' => 'LocationController@fetchCyclesList']);
    Route::get('dashboard/routes/all', ['as' => 'orders',  'middleware' => 'auth', 'uses' => 'RoutesController@fetchRoutesList']);
    Route::get('getDistrictList', ['as' => 'orders',  'middleware' => 'auth', 'uses' => 'RoutesController@getDistrictList']);
    Route::get('checkCycleNumber/{number}', ['as' => 'orders',  'middleware' => 'auth', 'uses' => 'LocationController@checkCycleNumber']);
    Route::get('getRelaventDistricts/{id}', ['as' => 'orders',  'middleware' => 'auth', 'uses' => 'RoutesController@getRelaventDistricts']);
    Route::get('dashboard/routes/add', ['as' => 'orders',  'middleware' => 'auth',  'uses' => 'RoutesController@addRoute']);
    Route::post('dashboard/route/addPrice', ['as' => 'orders', 'uses' => 'RoutesController@addPrice']);
    Route::post('getPriceQuotion', ['as' => 'orders', 'uses' => 'RoutesController@getPriceQuotion']);
    Route::get('dashboard/routes/view/{id}', ['as' => 'routes',  'middleware' => 'auth',  'middleware' => 'auth', 'uses' => 'RoutesController@getRouteDetails']);


    Route::post('dashboard/routes/add', ['as' => 'orders','uses' => 'RoutesController@addNewRoute']);
    Route::get('dashboard/locations/view/{id}', ['as' => 'orders',  'middleware' => 'auth', 'uses' => 'LocationController@viewLocation']);
    Route::get('dashboard/locations/get/{id}', ['as' => 'orders',  'middleware' => 'auth', 'uses' => 'LocationController@getLocations']);
    Route::get('dashboard/cycle/get/{id}', ['as' => 'orders',  'middleware' => 'auth', 'uses' => 'LocationController@getCycles']);
    Route::get('dashboard/locations/edit/{id}', ['as' => 'orders',  'middleware' => 'auth', 'uses' => 'LocationController@loadEditLocationForm']);
    Route::get('dashboard/orders/add', ['as' => 'orders', 'middleware' => 'auth', 'uses' => 'OrdersController@loadAddOrderForm']);
    Route::get('dashboard/order/{id}', ['as' => 'orders',  'middleware' => 'auth', 'uses' => 'OrdersController@getOrderDetails']);
    Route::get('dashboard/couriers/add', ['as' => 'orders',  'middleware' => 'auth', 'uses' => 'CourierController@loadAddCourierForm']);
    Route::get('dashboard/courier/{id}', ['as' => 'orders',  'middleware' => 'auth',  'uses' => 'CourierController@viewCourierDetails']);
    Route::get('dashboard/get_courier/{id}', ['as' => 'orders',  'middleware' => 'auth', 'uses' => 'CourierController@fetchCourierDetails']);
});
