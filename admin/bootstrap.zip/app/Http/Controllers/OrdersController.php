<?php

namespace App\Http\Controllers;

use App\District;
use App\DocType;
use App\LocationOrder;
use App\Order;
use App\ShipmentPurpose;
use Illuminate\Http\Request;

use App\Http\Requests;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class OrdersController extends Controller
{
    public function fetchOrdersList($order_status)
    {
		$data['order_status'] = $order_status;

		if($order_status == 'pending')
		{
			$data['orders'] = DB::table('orders')->join('customers', 'customers.id', '=', 'orders.user_id')->where('orders.flag', 0)->select('orders.*', 'customers.name as sender_name')->get();
		}
		else if($order_status == 'approved')
		{
			if(Auth::user()->role == 1) // if Admin
			{
				$data['locations'] = DB::table('locations')->get();
				$data['orders'] = DB::table('orders')->join('customers', 'customers.id', '=', 'orders.user_id')->LeftJoin('couriers', 'couriers.id', '=', 'orders.assigned_courier')->where('orders.flag', 1)->select('orders.*', 'customers.name as sender_name', 'couriers.first_name as c_first_name' , 'couriers.last_name as c_last_name')->get();
			}
			else if(Auth::user()->role == 3) // if Manager
			{
				$location_id = DB::table('locations')->where('manager_id', Auth::user()->id)->get();

				$data['locations'] = DB::table('locations')->where('manager_id', Auth::user()->id)->get();
				$data['orders'] = DB::table('orders')->join('customers', 'customers.id', '=', 'orders.user_id')->LeftJoin('couriers', 'couriers.id', '=', 'orders.assigned_courier')->where('orders.flag', 1)->where('location_id', $location_id[0]->id)->select('orders.*', 'customers.name as sender_name', 'couriers.first_name as c_first_name' , 'couriers.last_name as c_last_name')->get();
			}
			else if(Auth::user()->role == 9) // if Manager
			{
				$data['locations'] = DB::table('locations')->get();
				$data['orders'] = DB::table('orders')->join('customers', 'customers.id', '=', 'orders.user_id')->LeftJoin('couriers', 'couriers.id', '=', 'orders.assigned_courier')->where('orders.flag', 1)->where('assigned_courier', Auth::user()->id)->select('orders.*', 'customers.name as sender_name', 'couriers.first_name as c_first_name' , 'couriers.last_name as c_last_name')->get();
			}


		}
    	return view('admin.orders', $data);
    }

    public function loadOrders($order_status)
    {
		if($order_status == 'pending')
		{
			$data['orders'] = DB::table('orders')->join('customers', 'customers.id', '=', 'orders.user_id')->where('orders.flag', 0)->select('orders.*', 'customers.name as sender_name')->get();
		}
		else if($order_status == 'approved')
		{
			if(Auth::user()->role == 1) // if Admin
			{
				$data['locations'] = DB::table('locations')->get();
				$data['orders'] = DB::table('orders')->join('customers', 'customers.id', '=', 'orders.user_id')->LeftJoin('couriers', 'couriers.id', '=', 'orders.assigned_courier')->where('orders.flag', 1)->select('orders.*', 'customers.name as sender_name', 'couriers.first_name as c_first_name' , 'couriers.last_name as c_last_name')->get();
			}
			else if(Auth::user()->role == 3) // if Manager
			{
				$location_id = DB::table('locations')->where('manager_id', Auth::user()->id)->get();

				$data['locations'] = DB::table('locations')->where('manager_id', Auth::user()->id)->get();
				$data['orders'] = DB::table('orders')->join('customers', 'customers.id', '=', 'orders.user_id')->LeftJoin('couriers', 'couriers.id', '=', 'orders.assigned_courier')->where('orders.flag', 1)->where('location_id', $location_id[0]->id)->select('orders.*', 'customers.name as sender_name', 'couriers.first_name as c_first_name' , 'couriers.last_name as c_last_name')->get();
			}
			else if(Auth::user()->role == 9) // if Courier
			{
				$data['locations'] = DB::table('locations')->get();
				$data['orders'] = DB::table('orders')->join('customers', 'customers.id', '=', 'orders.user_id')->LeftJoin('couriers', 'couriers.id', '=', 'orders.assigned_courier')->where('orders.flag', 1)->where('assigned_courier', Auth::user()->id)->select('orders.*', 'customers.name as sender_name', 'couriers.first_name as c_first_name' , 'couriers.last_name as c_last_name')->get();
			}
		}
        return $data;
    }

	public function deleteOrderDetails($id)
	{
		DB::table('orders')->where('id', $id)->update(
				[
						'flag' => 11
				]
		);
	}

    public function addOrder(Request $request)
    {
    	$order = new Order();
    	$order->user_id = $request->user_id;
    	$order->sender_phone = $request->sender_phone;
    	$order->sender_street = $request->sender_street;
    	$order->sender_address_1 = $request->sender_address_1;
    	$order->sender_city = $request->sender_city;
		$order->sender_state = $request->sender_state;
		$order->sender_district = $request->sender_district;
		$order->sender_zipcode = $request->sender_zipcode;
		$order->sender_upazilla = $request->sender_upazilla;
    	$order->sender_country = $request->sender_country;
    	$order->reciever_name = $request->reciever_name;
		$order->reciever_email = $request->reciever_email;
		$order->reciever_phone = $request->reciever_phone;
		$order->reciever_street = $request->reciever_street;
		$order->reciever_address_1 = $request->reciever_address_1;
		$order->reciever_city = $request->reciever_city;
		$order->receiver_district = $request->receiver_district;
		$order->reciever_state = $request->reciever_state;

		$order->reciever_zipcode = $request->receiver_zipcode;
		$order->receiver_upazilla = $request->receiver_upazilla;
		$order->reciever_country = $request->reciever_country;
		$order->shipment_item_type = $request->doc_type;
		$order->pickup_date = $request->pickup_date;
		$order->payment_method = $request->payment_method;
		$order->shipment_info = serialize($request->shipment_info);

		$price = explode("_", $request->price);
		if($request->doc_type == 'parcel')
		{
			$order->shipping_time = $price[0];
			$order->price = $price[1];
		}
		else
		{
			$order->shipping_time = 72;
			$order->price = $request->price;
		}

		$order->flag = 0;
		$order->tracking_id = time().uniqid();
    	$order->save();
    }

	public function filterSearchOrder(Request $request)
	{
		echo 4;
	}

	public function getUpazilla($dist_id)
	{
		$data['upazillas'] = DB::table('upazillas')->where('district_id', $dist_id)->get();
		return view('ajax_views.upazillas', $data);
	}
	public function getOrderDetails($id)
	{
		$data['order'] = DB::table('orders')->join('customers', 'customers.id', '=', 'orders.user_id')->join('districts as sender_dist', 'sender_dist.id', '=', 'orders.sender_district')->join('upazillas as sender_upazilla', 'sender_upazilla.id', '=', 'orders.sender_upazilla')->join('upazillas as receiver_upazilla', 'receiver_upazilla.id', '=', 'orders.receiver_upazilla')->join('districts as receiver_dist', 'receiver_dist.id', '=', 'orders.receiver_district')->leftJoin('couriers', 'couriers.id', '=', 'orders.assigned_courier')->where('orders.id', $id)->select('orders.*', 'customers.name', 'customers.email', 'sender_dist.name as sender_district', 'receiver_dist.name as receiver_district', 'sender_upazilla.name as sender_upazilla_name', 'receiver_upazilla.name as receiver_upazilla', 'couriers.first_name', 'couriers.last_name')->get();
		return view('admin.order_details', $data);
	}

	public function assignCourier($order_id, $courier_id, $location_id)
	{
		DB::table('orders')->where('id', $order_id)->update(
				[
						'assigned_courier' => $courier_id,
						'location_id' => $location_id
				]
		);

		DB::table('location_order')->insert(
				[
						'order_id' => $order_id,
						'courier_id' => $courier_id,
						'location_id' => $location_id,
				]
		);
	}
	public function changeStatus($order_id, $status)
	{
		DB::table('orders')->where('id', $order_id)->update(
				[
					'flag' => $status
				]
		);
	}
    public function loadAddOrderForm()
    {
		$data['districts'] = District::get();
		$data['doc_types'] = DocType::get();
		$data['shipment_purposes'] = ShipmentPurpose::get();
    	return view('admin.add_order_form', $data);
    }
}
