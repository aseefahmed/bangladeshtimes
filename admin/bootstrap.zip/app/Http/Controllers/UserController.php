<?php

namespace App\Http\Controllers;

use App\Customer;
use App\Order;
use App\Permission;
use App\Role;
use App\User;
use Illuminate\Http\Request;
use App\Http\Requests;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Mail;

class UserController extends Controller
{
    public function viewLoginForm()
    {
        return view('login.index');
    }

    public function processLogin(Request $request)
    {
        if(Auth::attempt(['email' => $request->username, 'password' => $request->password]))
        {
            return Auth::user();
        }
        else
        {
            return -1;
        }
    }

    public function checkEmail(Request $request)
    {
        if($request->user_type == 'clients')
        {
            $count = Customer::where('email', $request->email)->count();
        }
        else if($request->user_type == 'employees')
        {
            $count = User::where('email', $request->email)->count();
        }

        if($count == 1)
            return -1;
        else if($count == 0)
            return 1;
    }

    public function doLogout()
    {
        Auth::logout();
        return redirect('login');
    }

    public function getUserDetails($id)
    {
        $data['user'] = Customer::where('id', $id)->get();
        $data['user_details'] = DB::table('orders')->where('user_id', $id)->get();
        return $data;
    }

    public function fetchReceiverDetails($name)
    {
        $data['user_details'] = Order::where('reciever_name', $name)->get();
        return $data;
    }
    public function loadUsersList($user_type)
    {
        $data['user_type'] = $user_type;
        if($user_type == 'clients')
        {
            $data['users'] = Customer::get();
        }
        else
        {
            $data['users'] = DB::table('users')->join('roles', 'users.role', '=', 'roles.id')->where('users.role', '!=', 0)->select('users.*', 'roles.name as role_name')->get();
        }
        return view('admin.users_list', $data);
    }

    public function resetPassword(Request $request)
    {
        $user = User::findOrFail(1);

        Mail::send('email.demo', ['user' => $user], function ($m) use ($user) {
            $m->from('hello@app.com', 'Your Application');

            $m->to($user->email, 'NRBExpress')->subject('Your Reminder!');
        });
        echo 'Basics Email was sent!';
    }
    public function forgetPassword()
    {
        return view('login.forget-password');
    }

    public function getUsersList($user_type)
    {
        if($user_type == 'clients')
        {
            $data['users'] = Customer::get();
        }
        else
        {
            $data['users'] = DB::table('users')->join('roles', 'users.role', '=', 'roles.id')->where('users.role', '!=', 0)->select('users.*', 'roles.name as role_name')->get();
        }

        return $data;

    }

    public function registerUser(Request $request)
    {
        $count = User::where('email', $request->email_address)->count();
        if($count > 0)
            return -1; // Email address already exists
        else
        {

            if($request->account_type)
            {
                $customer = new Customer();
                $customer->name = $request->first_name;
                $customer->account_type = $request->account_type;
                $customer->email = $request->email_address;
                $customer->password = Hash::make($request->email);
                $customer->status = 1;
                $customer->save();
            }
            else
            {
                $user = new User();
                $user->first_name = $request->first_name;
                $user->last_name = $request->last_name;
                $user->email = $request->email_address;
                $user->password = Hash::make($request->email);
                $user->role = $request->role;
                $user->save();
            }
        }
    }

    public function viewRoles()
    {
        return view('admin.roles');
    }

    public function viewPermissions()
    {
        return view('admin.permissions');
    }

    public function getRoles()
    {
        $data['roles'] = Role::get();
        return $data;
    }

    public function addRoles(Request $request)
    {
        $role = new Role();
        $role->name = $request->name;
        $role->name = $request->name;
        $role->save();
    }

    public function getPermissions()
    {
        $data['permissions'] = Permission::get();
        return $data;
    }

    public function addPermissions(Request $request)
    {
        $permission = new Permission();
        $permission->name = $request->name;
        $permission->display_name = $request->display_name;
        $permission->description = $request->description;
        $permission->save();
    }

    public function deleteUser($user_type, $id)
    {
        $data['user_type'] = $user_type;
        if($user_type == 'clients')
        {
            DB::table('customers')->where('id', $id)->delete();
        }
        else if($user_type == 'employees')
        {
            DB::table('users')->where('id', $id)->delete();
        }
    }

    public function viewUserDetails($user_type, $id)
    {
        $data['user_type'] = $user_type;
        if($user_type == 'employees')
        {
            $data['user'] = DB::table('users')->join('roles', 'roles.id', '=', 'users.role')->where('users.id', $id)->select('users.*', 'roles.name as role_name')->get();
        }
        else if($user_type == 'clients')
        {
            $data['user'] = DB::table('customers')->where('id', $id)->get();
        }

        return view('admin.user_details', $data);
    }

    public function assignPermission($role_id)
    {
        $data['role_id'] = $role_id;
        $data['role'] = Role::where('id', $role_id)->get();
        return view('admin.assign_permissions', $data);
    }

    public function logOut()
    {
        Auth::logout();
        return redirect('/');
    }

    public function assignPermissionToRole($val, $role, $permission_id)
    {
        $count = DB::table('permission_role')->where('role_id', $role)->where('permission_id', $permission_id)->count();
        if($count == 1)
        {
            DB::table('permission_role')->where('role_id', $role)->where('permission_id', $permission_id)->delete();
        }
        else
        {
            $result = DB::table('permission_role')->insert([
                'permission_id' => $permission_id,
                'role_id' => $role
            ]);
        }


    }
}
