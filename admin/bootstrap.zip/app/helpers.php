<?php

use App\Order;

function newOrders()
{
    $data = Order::take(5)->orderBy('id', 'desc')->get();
    return $data;
}

function isCourierInThisLocation($loc_id, $courier_id)
{
    $data = DB::table('courier_locations')->where('location_id', $loc_id)->where('courier_id', $courier_id)->count();
    return $data;
}

function isCourierGotCycle($courier_id)
{
    $data = DB::table('cycles')->where('courier_id', $courier_id)->where('flag', 1)->count();
    return $data;
}