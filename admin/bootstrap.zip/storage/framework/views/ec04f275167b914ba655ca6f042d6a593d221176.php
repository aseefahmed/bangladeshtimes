
<!doctype html>
<html lang="en" class="fixed accounts sign-in">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>NRB Express</title>
    <link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
    <link rel="icon" type="image/png" sizes="192x192" href="favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
    <!--BASIC css-->
    <!-- ========================================================= -->
    <link href="<?php echo e(asset('css/all.css')); ?>" rel="stylesheet" type="text/css"/>
</head>

<body>
<div class="wrap" ng-app="myApp" ng-controller="LoginController">
    <!-- page BODY -->
    <!-- ========================================================= -->
    <div class="page-body animated slideInDown">
        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
        <!--LOGO-->
        <div class="logo">
            <img alt="logo" src="<?php echo e(asset('img/logo.png')); ?>" />
        </div>
        <div class="box">
            <!--SIGN IN FORM-->
            <div class="panel mb-none">
                <div class="panel-content bg-scale-0">
                    <form id="formLogin" class="p-t-15" role="form">
                        <div class="form-group mt-md">
                            <span class="input-with-icon">
                                <input type="text" ng-model="email_address" placeholder="Email Address" class="form-control" ng-required="true">
                                <i class="fa fa-envelope"></i>
                            </span>
                        </div>
                        <div class="form-group">
                            <span class="input-with-icon">
                                <input type="password" class="form-control" ng-model="password" placeholder="Credentials" ng-required="true">
                                <i class="fa fa-key"></i>
                            </span>
                        </div>
                        <div class="form-group">
                            <div class="checkbox-custom checkbox-primary">
                                <input type="checkbox" id="remember-me" value="option1" checked>
                                <label class="check" for="remember-me">Remember me</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <a href="#" ng-click="doLogin()" class="btn btn-primary">Sign In</a>
                        </div>
                        <div class="form-group text-center">
                            <a href="<?php echo e(url('forget-password')); ?>">Forgot password?</a>
                            <?php /*<hr/>
                            <span>Don't have an account?</span>
                            <a href="pages_register.html" class="btn btn-block mt-sm">Register</a>*/ ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
    </div>
</div>
<!--BASIC scripts-->
<!-- ========================================================= -->
<script src="<?php echo e(asset('js/all.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('plugins/angular/angular.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/controller.js')); ?>" type="text/javascript"></script>
<!-- SECTION script and examples-->
<!-- ========================================================= -->
</body>

</html>
