<?php $__env->startSection('content'); ?>
    <div class="content sm-gutter" ng-controller="LocationController" ng-init="loadCouriersInLocationsList(<?php echo e($location[0]->id); ?>)">
        <div class="container-fluid padding-25 sm-padding-10">
            <div class="panel panel-transparent clearfix">
                <div class="panel-heading">
                    <div class="pull-left">
                        <div class="col-xs-12">
                            <button class="btn btn-primary btn-lg pull-right" data-target="#modalSlideUp" data-toggle="modal">ADD COURIER</button>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="panel-body clearfix">
                    <div class="row col-sm-2 clearfix">
                        <input type="text" class="form-control" ng-model="search_filter" placeholder="Search">
                    </div>
                    <table class="table table-hover demo-table-dynamic table-responsive-block" id="tableWithDynamicRows">
                        <thead>
                        <tr>
                            <th class="text-danger"><strong>Location Name:</strong> <?php echo e($location[0]->location_name); ?></th>
                        </tr>

                        </thead>
                    </table>

                    <div class="col-sm-4" ng-repeat="courier in location_based_couriers">
                        <% courier.first_name %> <% courier.last_name %>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade stick-up" id="modalSlideUp" tabindex="-1" role="dialog" aria-hidden="false">
            <div class="modal-dialog ">
                <div class="modal-content-wrapper">
                    <div class="modal-content">
                        <div class="modal-header clearfix text-left">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="pg-close fs-14"></i>
                            </button>
                            <h5>LOCATION <span class="semi-bold">INFORMATION</span></h5>
                            <p class="p-b-10">We need client information inorder to process the order</p>
                        </div>
                        <div class="modal-body">
                            <form role="form" name="addCourierToLocationForm" novalidate>
                                <div class="form-group-attached">

                                    <div class="row">
                                        <div class="col-sm-12" ng-if="msg != ''">
                                            <label><span style="color:red"><% msg %></span></label>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group form-group-default">
                                                <label>Courier <span style="color:red">*</span></label>
                                                <select class="form-control select2js"  name="courier_id" ng-model="location.courier_id" ng-required="true">
                                                    <option value="">Select a courier</option>
                                                    <?php
                                                        foreach($couriers as $courier){
                                                            echo "<option value=".$courier->id.">$courier->first_name $courier->last_name </option>";
                                                        }
                                                    ?>
                                                </select>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </form>
                            <div class="row">
                                <div class="col-sm-4 m-t-10 sm-m-t-10 pull-right">
                                    <a class="btn btn-primary btn-block m-t-5" ng-disabled="addCourierToLocationForm.$invalid" ng-click="addCourierToLocation(addCourierToLocationForm, <?php echo $location[0]->id;?>, location.courier_id)">ADD</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>