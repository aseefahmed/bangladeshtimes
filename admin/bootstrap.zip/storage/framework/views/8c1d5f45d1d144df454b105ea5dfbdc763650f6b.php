<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-3">
        <a class="btn btn-wide btn-success" >Pickup Date: <?php echo e(date_format(date_create($order[0]->pickup_date), 'g:s A, dS M, Y')); ?></a>
    </div>
    
    <div class="col-sm-3">
        <?php
            $date = date_create($order[0]->pickup_date);
            date_add($date, date_interval_create_from_date_string($order[0]->shipping_time.' hours'));
        ?>
        <a class="btn btn-wide btn-warning" >Estimated Delivery: <?php echo e(date_format($date, 'g:s A, dS M, Y')); ?></a>
    </div>

    <div class="col-sm-6 text-right">
        <strong>Status:</strong>
        <a class="text-primary" data-toggle="modal" href="" data-target="#success-modal">
            <?php if($order[0]->flag == 0): ?>
                <strong class="badge x-danger">Pending</strong>
            <?php elseif($order[0]->flag == 1): ?>
                <strong class="badge x-success">Approved</strong>
            <?php elseif($order[0]->flag == 2): ?>
                <strong class="badge x-warning">Wating for Scan</strong>
            <?php elseif($order[0]->flag == 3): ?>
                <strong class="badge x-warning">In Transit</strong>
            <?php elseif($order[0]->flag == 4): ?>
                <strong class="badge x-warning">Moved Further</strong>
            <?php elseif($order[0]->flag == 5): ?>
                <strong class="badge x-warning">Shipment Arrived</strong>
            <?php elseif($order[0]->flag == 6): ?>
                <strong class="badge x-warning">Dispatched for Delivery</strong>
            <?php elseif($order[0]->flag == 7): ?>
                <strong class="badge x-warning">Returned</strong>
            <?php elseif($order[0]->flag ==8): ?>
                <strong class="badge x-warning">Hold</strong>
            <?php elseif($order[0]->flag == 9): ?>
                <strong class="badge x-warning">Delivered</strong>
            <?php elseif($order[0]->flag == 10): ?>
                <strong class="badge x-warning">Cancelled</strong>
            <?php endif; ?>
        </a>
    </div>
</div>

<div class="row">
    <div class="col-sm-6">
        <div class="panel">
            <div class="panel-header panel-warning">
                <h3 class="panel-title">Sender Information</h3>                
            </div>
            <div class="panel-content">                        
                <ul class="user-contact-info ph-sm">
                    <li><b><i class="color-primary mr-sm fa fa-user"></i></b> <strong>Name:</strong> <?php echo e($order[0]->name); ?></li>
                    <li><b><i class="color-primary mr-sm fa fa-envelope"></i></b> <strong>Email:</strong> <?php echo e($order[0]->email); ?></li>
                    <li><b><i class="color-primary mr-sm fa fa-phone"></i></b> <strong>Phone:</strong> <?php echo e($order[0]->sender_phone); ?></li>
                    <li><b><i class="color-primary mr-sm fa fa-map-marker"></i></b> <strong>Address:</strong> <?php echo e($order[0]->sender_street); ?></li>                    
                    <li><b><i class="color-primary mr-sm fa fa-map-marker"></i></b> <strong>District:</strong> <?php echo e($order[0]->sender_district); ?></li>
                    <li><b><i class="color-primary mr-sm fa fa-map-marker"></i></b> <strong>Upazilla:</strong> <?php echo e($order[0]->sender_upazilla_name); ?></li>                
                    <li><b><i class="color-primary mr-sm fa fa-map-marker"></i></b> <strong>Post Code:</strong> <?php echo e($order[0]->sender_zipcode); ?></li>
                </ul>                            
            </div>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="panel">
            <div class="panel-header  panel-warning">
                <h3 class="panel-title">Receiver Information</h3>                
            </div>
            <div class="panel-content">
            	<ul class="user-contact-info ph-sm">
                    <li><b><i class="color-primary mr-sm fa fa-user"></i></b> <strong>Name:</strong> <?php echo e($order[0]->reciever_name); ?></li>
                    <li><b><i class="color-primary mr-sm fa fa-envelope"></i></b> <strong>Email:</strong> <?php echo e($order[0]->reciever_email); ?></li>
                    <li><b><i class="color-primary mr-sm fa fa-phone"></i></b> <strong>Phone:</strong> <?php echo e($order[0]->reciever_phone); ?></li>
                    <li><b><i class="color-primary mr-sm fa fa-map-marker"></i></b> <strong>Address:</strong> <?php echo e($order[0]->reciever_street); ?></li>                    
                    <li><b><i class="color-primary mr-sm fa fa-map-marker"></i></b> <strong>District:</strong> <?php echo e($order[0]->receiver_district); ?></li>
                    <li><b><i class="color-primary mr-sm fa fa-map-marker"></i></b> <strong>Upazilla:</strong> <?php echo e($order[0]->receiver_upazilla); ?></li>                
                    <li><b><i class="color-primary mr-sm fa fa-map-marker"></i></b> <strong>Post Code:</strong> <?php echo e($order[0]->reciever_zipcode); ?></li>
                </ul>
                                
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-sm-6">
        <div class="panel">
            <div class="panel-header panel-success">
                <h3 class="panel-title">Product Information</h3>                
            </div>
            <div class="panel-content">
            <?php
				$items = unserialize($order[0]->shipment_info);
				$total_weight = 0;
			?>
            <div class="table-responsive">
              <table class="table table-striped table-hover">
                <thead>
                  <tr>
                    <th>Item Name</th>
                    <th>Quantity</th>
                    <th>Weight</th>
                  </tr>
                </thead>
                <tbody>
                
                 <?php if(count($items)>0): ?>
                    <?php foreach($items as $item): ?>
                    
                     <tr>
                        <td><?php echo e($item[0]); ?></td>
                        <td>
                        	<?php if(strlen($item[3]) != 0): ?>
                                <?php echo e($item[3]); ?>

                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                        	<?php if(strlen($item[2]) != 0): ?>
                                <?php echo e($item[2]); ?>

                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                      </tr>
                        <?php
                        $total_weight += $item[2];
                        ?>
                    <?php endforeach; ?>
                <?php endif; ?>     
                </tbody>
              </table>
            </div>
            </div>
        </div>
    </div>
    
     <div class="col-md-6 col-lg-6 pull-right">     
        <div class="panel">
            <div class="panel-header panel-success">
            	<h3 class="panel-title">Order Summary</h3>
            </div>
            <div class="panel-content">
                <ul class="user-contact-info ph-sm">
                    <?php if($total_weight != 0): ?>
                    <li><b>Total Wight: </b> <?php echo e($total_weight); ?> Kg</li>
                    <?php endif; ?>
                    <li><b>Total Items: </b> <?php echo e(count($items)); ?> Item(s)</li>
                    <li><b>Payment Method: </b> <?php echo e($order[0]->payment_method); ?></li>
                    <li><b>Estimated Delimery Time </b> <?php echo e($order[0]->shipping_time); ?> Hour</li>
                    <li><b>Net Cost: </b> <?php echo e($order[0]->price); ?> Tk.</li>
                </ul>
            </div>        
        </div>               
    </div>    
</div>

<div class="row">
    <div class="col-sm-6">    
        <div class="panel">
            <div class="panel-header  panel-info">
                <h3 class="panel-title">Location map View</h3>                
            </div>
            <div class="panel-content">                         
           <!-- <div class="p-info">
                <ul>
                    <li><span>Total Distance</span> <span id="total"></span></li>
                    <li><span>Created</span> 05-08-16</li>
                </ul>
                <ul>
                    <li><span>Contact Person</span>Daniel Tomas</li>
                    <li><span>Contact Phone</span>234.45.56.78</li>
                </ul>
            </div>--> 
                <div id="map"></div>
            </div>
        </div>    
    </div>
    
    <div class="col-sm-6">    
        <div class="panel">
            <div class="panel-header  panel-info">
                <h3 class="panel-title">Distance and Driving Instruction</h3>                
            </div>
            <div class="panel-content">
                <div id="right-panel">
                  <p><strong>Total Distance: <span id="total"></span></strong></p>
                </div>
            </div>
        </div>    
    </div>
    
</div>
<style>
#map {
	height:400px;
  }
</style>
<script>
      function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 6,
          center: {lat: 23.7561, lng: 90.3872}  // Bangladesh.
        });

        var directionsService = new google.maps.DirectionsService;
        var directionsDisplay = new google.maps.DirectionsRenderer({
          draggable: true,
          map: map,
          panel: document.getElementById('right-panel')
        });

        directionsDisplay.addListener('directions_changed', function() {
          computeTotalDistance(directionsDisplay.getDirections());
        });

        displayRoute('<?php echo e($order[0]->sender_street); ?> <?php echo e($order[0]->sender_upazilla_name); ?> <?php echo e($order[0]->sender_district); ?>', '<?php echo e($order[0]->reciever_street); ?>, <?php echo e($order[0]->receiver_upazilla); ?> <?php echo e($order[0]->receiver_district); ?>', directionsService, directionsDisplay);
      }

      function displayRoute(origin, destination, service, display) {
        service.route({
          origin: origin,
          destination: destination,
          /*waypoints: [{location: 'Adelaide, SA'}, {location: 'Broken Hill, NSW'}],*/
          travelMode: 'DRIVING',
          avoidTolls: true
        }, function(response, status) {
          if (status === 'OK') {
            display.setDirections(response);
          } else {
            alert('Could not display directions due to: ' + status);
          }
        });
      }

      function computeTotalDistance(result) {
        var total = 0;
        var myroute = result.routes[0];
        for (var i = 0; i < myroute.legs.length; i++) {
          total += myroute.legs[i].distance.value;
        }
        total = total / 1000;
        document.getElementById('total').innerHTML = total + ' km';
      }
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCQAuKSPQX1pwWUMf9nZF5xBEoESF41_WQ&callback=initMap">
    </script>

<div class="modal fade" id="success-modal" tabindex="-1" role="dialog" aria-labelledby="modal-success-label" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header state modal-success">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="modal-success-label"><i class="fa fa-anchor"></i>Change Order Status</h4>
            </div>
            <div class="modal-body">
                <form role="form" name="userRegistrationForm" id="userRegistrationForm" novalidate>
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group-attached">

                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group form-group-default">
                                    <label>Status<span style="color:red">*</span></label>
                                    <select class="form-control" id="order_order_status" order_id="<?php echo e($order[0]->id); ?>">
                                        <option value="-1">Select Order Status</option>
                                        <option value="1">Approved</option>
                                        <option value="2">Wating for Scan</option>
                                        <option value="9">Delivered</option>
                                    </select>
                                </div>
                            </div>


                        </div>
                    </div>
                </form>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <div class="col-sm-6" ng-if="userRegistrationForm.email_address.$dirty && userRegistrationForm.email_address.$invalid">
                        <label><span style="color:red">* Email address must be valid.</span></label>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="col-sm-12" ng-if="userRegistrationForm.password.$dirty && userRegistrationForm.password.$invalid">
                        <label><span style="color:red">* Password must be at least 8 characters long and should contain one number,one character and one special character.</span></label>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="col-sm-12" ng-if="userRegistrationForm.retype_password.$dirty && user.retype_password!=user.password">
                        <label><span style="color:red">* Password and re-type password must be same.</span></label>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-success" ng-disabled="userRegistrationForm.$invalid" id="user_reg_btn">Ok</a>
                <a type="button" class="btn btn-default" data-dismiss="modal">Close</a>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>