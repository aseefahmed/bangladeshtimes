<!doctype html>
<html lang="en" class="fixed">


<!-- Mirrored from myiideveloper.com/helsinki/helsinki-green/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 23 Feb 2017 08:56:36 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>NRB Express</title>
    <link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
    <link rel="icon" type="image/png" sizes="192x192" href="favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
    <link href="<?php echo e(asset('css/all.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
    <link href="https://cdn.datatables.net/buttons/1.2.4/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('css/datetimepicker.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/datetimepicker.css')); ?>" rel="stylesheet" type="text/css">
    <style>
        input.submitted.ng-invalid
        {
            border:1px solid #f00;
        }
        select.submitted.ng-invalid
        {
            border:1px solid #f00;
        }
    </style>
</head>

<body ng-app="myApp">
<div class="wrap">
    <div class="page-header">
        <div class="leftside-header">
            <div class="logo">
                <a href="<?php echo e(url('/dashboard')); ?>" class="on-click">
                    <img alt="logo" src="<?php echo e(asset('img/logo.png')); ?>" />
                </a>
            </div>
            <div id="menu-toggle" class="visible-xs toggle-left-sidebar" data-toggle-class="left-sidebar-open" data-target="html">
                <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
            </div>
        </div>
        <div class="rightside-header">
            <div class="header-middle"></div>
            
            <div class="header-section hidden-xs" id="notice-headerbox">
                
                
                <div class="notice" id="alerts-notice">
                    <i class="fa fa-bell-o" aria-hidden="true"><span class="badge badge-xs badge-top-right x-danger">New</span></i>
                    <div class="dropdown-box basic">
                        <div class="drop-header">
                            <h3><i class="fa fa-bell-o" aria-hidden="true"></i> Notifications</h3>
                            <span class="badge x-danger b-rounded">New</span>
                        </div>
                        <div class="drop-content">
                            <div class="widget-list list-left-element list-sm">
                                <ul>
                                    <?php foreach(newOrders() as $order): ?>
                                        <li>
                                            <a href="#">
                                                <div class="left-element"><i class="fa fa-warning color-warning"></i></div>
                                                <div class="text">
                                                    <span class="title"><?php echo e($order->reciever_name); ?></span>
                                                    <span class="subtitle">Date: <?php echo e(date_format(date_create($order->pickup_date), 'Y-m-d')); ?></span>
                                                </div>
                                            </a>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="header-separator"></div>
            </div>
            <div class="header-section" id="user-headerbox">
                <div class="user-header-wrap">
                    <div class="user-photo">
                        <img src="<?php echo e(url('img/profiles/1.jpg')); ?>" alt="<?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?>" />
                    </div>
                    <div class="user-info">
                        <span class="user-name"><?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?></span>
                        <?php if(Auth::user()->role == 1): ?>
                            <span class="user-profile">Admin</span>
                        <?php endif; ?>
                    </div>
                    <i class="fa fa-plus icon-open" aria-hidden="true"></i>
                    <i class="fa fa-minus icon-close" aria-hidden="true"></i>
                </div>
                <div class="user-options dropdown-box">
                    <div class="drop-content basic">
                        <ul>
                            <li> <a href="#"><i class="fa fa-user" aria-hidden="true"></i> Profile</a></li>
                            <li> <a href="#"><i class="fa fa-lock" aria-hidden="true"></i> Lock Screen</a></li>
                            <li><a href="#"><i class="fa fa-cog" aria-hidden="true"></i> Configurations</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="header-separator"></div>
            <div class="header-section">
                <a href="<?php echo e(url('logout')); ?>" data-toggle="tooltip" data-placement="left" title="Logout"><i class="fa fa-sign-out log-out" aria-hidden="true"></i></a>
            </div>
        </div>
    </div>
    <div class="page-body">
        <div class="left-sidebar">
            <!-- left sidebar HEADER -->
            <div class="left-sidebar-header">
                <div class="left-sidebar-title">Navigation</div>
                <div class="left-sidebar-toggle c-hamburger c-hamburger--htla hidden-xs" data-toggle-class="left-sidebar-collapsed" data-target="html">
                    <span></span>
                </div>
            </div>
            <!-- NAVIGATION -->
            <!-- ========================================================= -->
            <div id="left-nav" class="nano">
                <div class="nano-content">
                    <nav>
                        <ul class="nav" id="main-nav">
                            <!--HOME-->
                            <li class="active-item"><a href="<?php echo e(url('/dashboard')); ?>"><i class="fa fa-home" aria-hidden="true"></i><span>Dashboard</span></a></li>
                            <!--UI ELEMENTENTS-->
                            <?php if(Auth::user()->role == 1 ): ?>
                                <li class="has-child-item close-item">
                                    <a><i class="fa fa-users" aria-hidden="true"></i><span>User Accounts</span></a>
                                    <ul class="nav child-nav level-1">
                                        <li><a href="<?php echo e(url('dashboard/clients/list')); ?>">Customers</a></li>
                                        <li><a href="<?php echo e(url('dashboard/employees/list')); ?>">Employees</a></li>
                                    </ul>
                                </li>
                            <?php endif; ?>
                            <!--CHARTS-->
                            <li class="has-child-item close-item">
                                <a><i class="fa fa-gift" aria-hidden="true"></i><span>Online Orders</span> </a>
                                <ul class="nav child-nav level-1">
                                    <?php if(Auth::user()->role == 1): ?>
                                        <li><a href="<?php echo e(url('dashboard/orders/all/pending')); ?>">Pending Orders</a></li>
                                    <?php endif; ?>
                                    <li><a href="<?php echo e(url('dashboard/orders/all/approved')); ?>">Approved Orders</a></li>
                               </ul>
                            </li>
                            <!--FORMS-->
                            <?php if(Auth::user()->role == 1 || Auth::user()->role == 3 ): ?>
                                <li class="has-child-item close-item">
                                    <a><i class="fa fa-user" aria-hidden="true"></i><span>Couriers </span></a>
                                    <ul class="nav child-nav level-1">
                                        <li><a href="<?php echo e(url('dashboard/couriers/all')); ?>">View All</a></li>
                                    </ul>
                                </li>
                            <?php endif; ?>
                            <!--FORMS-->
                            <?php if(Auth::user()->role == 1): ?>
                                <li class="has-child-item close-item">
                                    <a><i class="fa fa-map-marker" aria-hidden="true"></i><span>Location </span></a>
                                    <ul class="nav child-nav level-1">
                                        <li><a href="<?php echo e(url('dashboard/locations/all')); ?>">View All</a></li>
                                    </ul>
                                </li>
                            <?php endif; ?>
                            <!--FORMS-->
                            <?php if(Auth::user()->role == 1): ?>
                                <li class="has-child-item close-item">
                                    <a><i class="fa fa-bicycle" aria-hidden="true"></i><span>Cycles </span></a>
                                    <ul class="nav child-nav level-1">
                                        <li><a href="<?php echo e(url('dashboard/cycles/all')); ?>">View All</a></li>
                                    </ul>
                                </li>
                            <?php endif; ?>
                            <!--FORMS-->
                            <?php if(Auth::user()->role == 1): ?>
                                <li class="has-child-item close-item">
                                    <a><i class="fa fa-mars-double" aria-hidden="true"></i><span>Routes </span></a>
                                    <ul class="nav child-nav level-1">
                                        <li><a href="<?php echo e(url('dashboard/routes/all')); ?>">View All</a></li>
                                    </ul>
                                </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->role == 1): ?>
                                <li class="has-child-item close-item">
                                    <a><i class="fa fa-cog" aria-hidden="true"></i><span>Accounts Settings</span></a>
                                    <ul class="nav child-nav level-1">
                                        <li><a href="<?php echo e(url('dashboard/roles')); ?>">Roles</a></li>
                                        <li><a href="<?php echo e(url('dashboard/permissions')); ?>">Permissions</a></li>
                                    </ul>
                                </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->role == 1): ?>
                                <li class="has-child-item close-item">
                                    <a><i class="fa fa-bar-chart" aria-hidden="true"></i><span>All Reports</span></a>
                                    <ul class="nav child-nav level-1">
                                        <li><a href="<?php echo e(url('dashboard/roles')); ?>">Pending</a></li>
                                        <li><a href="<?php echo e(url('dashboard/permissions')); ?>">Delivered</a></li>
                                    </ul>
                                </li>
                            <?php endif; ?>

                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="content-header">
                <div class="leftside-content-header">
                    <ul class="breadcrumbs">
                        <li><i class="fa fa-home" aria-hidden="true"></i><a href="#">Dashboard</a></li>
                    </ul>
                </div>
            </div>
            <div class="row animated fadeInUp">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
        <a href="#" class="scroll-to-top"><i class="fa fa-angle-double-up"></i></a>
    </div>
</div>
<script src="<?php echo e(asset('js/all.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('plugins/angular/angular.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/controller.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/datetimepicker.js')); ?>" type="text/javascript"></script>

<script src="<?php echo e(asset('plugins/select2/js/select2.full.min.js')); ?>" type="text/javascript"></script>

<script src="<?php echo e(asset('plugins/bootstrap-fileinput/js/fileinput.min.js')); ?>" type="text/javascript"></script>

<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js">
</script>
<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.2.4/js/dataTables.buttons.min.js">
</script>
<script type="text/javascript" language="javascript" src="//cdn.datatables.net/buttons/1.2.4/js/buttons.flash.min.js">
</script>
<script type="text/javascript" language="javascript" src="//cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js">
</script>
<script type="text/javascript" language="javascript" src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.24/build/pdfmake.min.js">
</script>
<script type="text/javascript" language="javascript" src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.24/build/vfs_fonts.js">
</script>
<script type="text/javascript" language="javascript" src="//cdn.datatables.net/buttons/1.2.4/js/buttons.html5.min.js">
</script>
<script type="text/javascript" language="javascript" src="//cdn.datatables.net/buttons/1.2.4/js/buttons.print.min.js">
</script>
<script>
$(document).ready(function()  {
/*
    $('.default_datetimepicker').datetimepicker();*/

    $('#user_reg_btn').click(function(){
        user_type = $('#user_reg_btn').attr('user_type');
        formData = new FormData($("#userRegistrationForm")[0]);
        $.ajax({
            url: "<?php echo e(url('registerUser')); ?>",
            method: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
                $('.success_div').css('display', 'block');
                $('#success-modal').modal('toggle');
                window.location.href = app.host + 'dashboard/'+user_type+'/list';
            }
        }).fail(function(result){
            console.log(result)
        });
    });
    $('#same_add_chk').click(function(){
        var present_address = $('#present_address').val();
        if($('#same_add_chk').prop('checked'))
        {
            $('#permanent_address').val(present_address);
        }
        else
        {
            $('#permanent_address').val('');
        }
    })
    $('#sender_input').change(function(){console.log('dd')
        formData = new FormData($("#userRegistrationForm")[0]);
        $.ajax({
            url: "<?php echo e(url('filterSearchOrder')); ?>",
            method: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
                $('#modalSlideUp').modal('toggle');
                console.log(result)
            }
        }).fail(function(result){
            console.log(result)
        });
    });
    $('#user_id').change(function(){
        user_id = $('#user_id').val();
        formData = new FormData($("#OrderRequestForm")[0]);
        $.ajax({
            url: "<?php echo e(url('fetchUserDetails')); ?>/"+user_id,
            method: "GET",
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
                console.log(result)
                //window.location.href = app.host + 'dashboard/order/'+order_id;
            }
        }).fail(function(result){
            console.log(result)
        });
    });

    $('#delivery_type').change(function(){
        val = $('#delivery_type').val();
        if(val == 'regular')
        {
            $('#regular').css('display', 'block')
            $('#express').css('display', 'none')
        }
        else if(val == 'express')
        {
            $('#express').css('display', 'block')
            $('#regular').css('display', 'none')
        }
    })

    $('#sender_id').change(function(){
        val = $('#sender_id').val();
        index = val.indexOf('-');
        account_type = val.substr(index+1);
    })
    $('#assign_courier_btn').click(function(){
        var order_id = $('#select_location').attr('order_id');
        var location_id = $('#select_location').val();
        var courier_id = $('#select_courier').val();
        $.ajax({
            url: "<?php echo e(url('assignCourier')); ?>/"+order_id+'/'+courier_id+'/'+location_id,
            method: "GET",
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
                console.log(result)
                window.location.href = app.host + 'dashboard/orders/all/approved';
            }
        }).fail(function(result){
            console.log(result)
        });
    });
    $('#select_location').change(function(){
        var location = $('#select_location').val();

        if(location != 0)
        {
            $.ajax({
                url: "<?php echo e(url('getLocationbasedCourier')); ?>/"+location,
                method: "GET",
                contentType: false,
                cache: false,
                processData:false,
                success: function(result){
                    console.log(result)
                    $('#select_courier').html(result);
                    $('#select_courier').prop('disabled', false);
                }
            }).fail(function(result){
                console.log(result)
            });
        }
        else
        {
            $('#select_courier').prop('disabled', 'disabled');
        }
    });
    $('#btn-add-price-chart').click(function(){
        var route_id = $('#route_id').attr('route');
        formData = new FormData($("#addPriceChart")[0]);
        $.ajax({
            url: "<?php echo e(url('dashboard/route/addPrice')); ?>",
            method: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
                $('#modalSlideUp').modal('toggle');
                window.location.href = app.host + 'dashboard/routes/view/'+route_id;
            }
        }).fail(function(result){
            console.log(result)
        });
    });
    $('#generate_location_btn').click(function(){
        formData = new FormData($("#locationForm")[0]);
        $.ajax({
            url: "<?php echo e(url('dashboard/routes/add')); ?>",
            method: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
                $('#modalSlideUp').modal('toggle');
                window.location.href = app.host + 'dashboard/routes/all';
            }
        }).fail(function(result){
            console.log(result)
        });
    });
    $('#add_courier_btn').click(function(){
        formData = new FormData($("#CourierRequestForm")[0]);
        $.ajax({
            url: "<?php echo e(url('dashboard/couriers/add')); ?>",
            method: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
                console.log(result)
                window.location.href = app.host + 'dashboard/couriers/all';
            }
        }).fail(function(result){
            console.log(result)
        });
    });
    $('#doc_item_input').change(function(){
        item_id = $('#doc_item_input').val();
        if(item_id == 'Your document description')
        {
            $('#other_div').css('display', 'block')
        }
        else
        {
            $('#other_div').css('display', 'none');
        }
    })
    $('#sender_district').change(function(){
        var sender_district = $('#sender_district').val();

        if(sender_district != 0)
        {
            $.ajax({
                url: "<?php echo e(url('getUpazilla')); ?>/"+sender_district,
                method: "GET",
                contentType: false,
                cache: false,
                processData:false,
                success: function(result){;
                    $('#sender_upazilla').html(result)
                    $('#sender_upazilla').prop('disabled', false);
                }
            }).fail(function(result){
                console.log(result)
            });
        }
        else
        {
            $('#sender_upazilla').prop('disabled', 'disabled');
        }
    });
    $('#receiver_district').change(function(){
        var receiver_district = $('#receiver_district').val();

        if(receiver_district != 0)
        {
            $.ajax({
                url: "<?php echo e(url('getUpazilla')); ?>/"+receiver_district,
                method: "GET",
                contentType: false,
                cache: false,
                processData:false,
                success: function(result){;
                    $('#receiver_upazilla').html(result)
                    $('#receiver_upazilla').prop('disabled', false);
                }
            }).fail(function(result){
                console.log(result)
            });
        }
        else
        {
            $('#receiver_upazilla').prop('disabled', 'disabled');
        }
    });
    $('#order_order_status').change(function(){
        var order_id = $('#order_order_status').attr('order_id');
        var status = $('#order_order_status').val();
        if(status == -1)
        {
            return;
        }
        else
        {
            $.ajax({
                url: "<?php echo e(url('changeOrderStatus')); ?>/"+order_id+"/"+status,
                method: "GET",
                contentType: false,
                cache: false,
                processData:false,
                success: function(result){;
                   window.location.href = app.host + 'dashboard/order/'+order_id;
                }
            }).fail(function(result){
                console.log(result)
            });
        }
    });
    $('#responsive-table').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    });

    $('.select2js').select2();
    $('.default_datetimepicker').datetimepicker({
        allowTimes: ['09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00'],
    });
    $('.default_datetimepicker_without_time').datetimepicker({
        timepicker:false,
    });
            $(this).change(function(){
        date = new Date($(this).val());
        day = date.getDate();
        month = date.getMonth()+1;
        year = date.getFullYear();
        if(month < 10)
        {
            month = "0"+month;
        }
        if(day < 10)
        {
            day = "0"+day;
        }
        $(this).val(year + "-" + month + "-" + day);
    });
    $(".fileinput").fileinput({'showUpload':false, 'previewFileType':'any'});

})
</script>
</body>

<!-- Mirrored from pages.revox.io/dashboard/latest/html/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 02 Jan 2017 04:46:22 GMT -->
</html>