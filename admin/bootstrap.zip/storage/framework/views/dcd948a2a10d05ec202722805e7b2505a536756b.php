<?php $__env->startSection('content'); ?>
    <div class="col-sm-12">
        <div class="row">
            <div class="col-sm-4 col-lg-3">
                <div class="panel widgetbox wbox-3 bg-primary ">
                    <a href="#">
                        <div class="panel-content">
                            <span class="icon fa fa-users"></span>
                            <h1 class="title color-darker-2">Total Customer</h1>
                            <h4 class="numbers"><b><?php echo e(rand(10, 99)); ?></b></h4>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-sm-4 col-lg-3">
                <div class="panel widgetbox wbox-3 bg-warning ">
                    <a href="#">
                        <div class="panel-content">
                            <span class="icon fa fa-gift"></span>
                            <h1 class="title color-darker-2">Total Order</h1>
                            <h4 class="numbers"><b><?php echo e(rand(10, 99)); ?></b></h4>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-sm-4 col-lg-3">
                <div class="panel widgetbox wbox-3 bg-danger ">
                    <a href="#">
                        <div class="panel-content">
                            <span class="icon fa fa-user"></span>
                            <h1 class="title color-darker-2">Total Courier</h1>
                            <h4 class="numbers"><b><?php echo e(rand(10, 99)); ?></b></h4>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-sm-4 col-lg-3">
                <div class="panel widgetbox wbox-3 bg-success ">
                    <a href="#">
                        <div class="panel-content">
                            <span class="icon fa fa-bicycle"></span>
                            <h1 class="title color-darker-2">Total Deliverd</h1>
                            <h4 class="numbers"><b><?php echo e(rand(10, 99)); ?></b></h4>
                        </div>
                    </a>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>