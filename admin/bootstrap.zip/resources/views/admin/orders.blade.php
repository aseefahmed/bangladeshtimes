@extends('layouts.admin.dashboard')

@section('content')
    <form role="form" name="userRegistrationForm" id="userRegistdrationForm" novalidate>
    {{ csrf_field() }}
    <div class="col-sm-12" ng-controller="OrderController" ng-init="loadOrdersList('{{$order_status}}')">
        <div class="pull-left">
            <div class="col-xs-12">
                <a href="{{ url('dashboard/orders/add') }}" class="btn btn-wide btn-success" >ADD ORDER</a>
            </div>
        </div>


            <div class="container-fluid padding-25 sm-padding-10">
            <div class="clearfix"></div>
            <div class="panel panel-transparent clearfix">
                <div class="panel-heading">

                </div>
                <div class="panel-body clearfix">

                    <div class="panel-group" id="accordion_group4">
                        <div class="panel panel-accordion">
                            <div class="panel-header panel-primary">
                                <a class="panel-title collapsed" data-toggle="collapse" data-parent="#accordion_group4" href="#accordion-bg-1">
                                    <i class="fa fa-caret-right"></i> Advanced Search
                                </a>
                            </div>
                            <div id="accordion-bg-1" class="panel-collapse collapse">
                                <div class="panel-content">
                                        <div class="col-sm-3">
                                            <input type="text" placeholder="Sender" id="sender_input" class="form-control" name="sender" id="sender">
                                        </div>
                                        <div class="col-sm-3">
                                            <input type="text" placeholder="Receiver" class="form-control" name="receiver" id="default_datetimepicker">
                                        </div>
                                        <div class="col-sm-3">
                                            <input placeholder="Tracking ID" type="text" class="form-control" name="tracking_id">
                                        </div>
                                        <div class="col-sm-3">
                                            &nbsp;
                                        </div>
                                        <div class="col-sm-3">
                                            &nbsp;
                                        </div>

                                        <div class="col-sm-3">
                                            <input placeholder="Pickup Date" type="text" class="form-control default_datetimepicker" name="pickup_date">
                                        </div>
                                        <div class="col-sm-3">
                                            <input placeholder="Delivery Date" type="text" class="form-control default_datetimepicker" name="order_date">
                                        </div>
                                        <div class="col-sm-3">
                                            <button class="btn btn-primary" id="order_filter_btn"><i class="fa fa-filter"></i> Apply Filter</button>
                                        </div>
                                    <br><br><br><br>

                                </div>
                            </div>
                        </div>
                    </div>
                    <table class="table table-hover demo-table-dynamic table-responsive-block" id="responsive-table">
                        <thead>
                        <tr>
                            <th>Sender</th>
                            <th>Reciever</th>
                            <th>Shipping_method</th>
                            <th>Pickup Date</th>
                            <th>ETD</th>
                            <th>Status</th>
                            <th>Acttion</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($orders as $order)
                            <tr>
                                <td>{{ $order->sender_name }}</td>
                                <td>{{ $order->reciever_name }}</td>
                                <td>
                                    @if($order->shipping_time < 20)
                                        Express
                                    @else
                                        Regular
                                    @endif
                                </td>
                                <td>{{ date_format(date_create($order->pickup_date), 'Y-m-d') }}</td>
                                <td>
                                    <?php
                                    $date = date_create($order->pickup_date);
                                    date_add($date, date_interval_create_from_date_string($order->shipping_time.' hours'));
                                    echo date_format($date, 'Y-m-d g:i A');
                                    ?>
                                </td>
                                <td>Pending</td>
                                <td>

                                    <a  href="{{ url('dashboard/order/'.$order->id) }}" class="btn btn-success"><i class="fa fa-eye"></i></a>
                                    @if($order->flag == 1 && $order->assigned_courier == 0)
                                        <a order_id="<% order.id %>" ng-click="openModal({{ $order->id }})" class="btn btn-danger"><i class="fa fa-user"></i> Assign to Courier </a>
                                    @elseif($order->flag == 1 && $order->assigned_courier != 0)
                                        @if($order->assigned_courier != Auth::user()->id)
                                            <a order_id="<% order.id %>" ng-click="openModal({{ $order->id }})" class="btn btn-warning"><i class="fa fa-user"></i> Assigned to {{ $order->c_first_name }}</a>
                                        @endif
                                    @elseif($order->flag != 1)
                                        <a ng-click="delete_order(<?php echo $order->id;?>)" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                                    @endif
                               </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    <!-- Modal -->
                    <div class="modal fade" id="success-modal" tabindex="-1" role="dialog" aria-labelledby="modal-success-label" data-keyboard="false" data-backdrop="static">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header state modal-success">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="modal-success-label"><i class="fa fa-user"></i>Assign To Courier</h4>
                                </div>
                                <div class="modal-body">

                                        <div class="form-group-attached">
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div class="form-group form-group-default">
                                                        <label>Location<span style="color:red">*</span></label>
                                                        <select class="form-control" order_id="<% $order_id %>" id="select_location">
                                                            <option value="0">Select Location</option>
                                                            <option ng-repeat="location in locations" value="<% location.id %>"><% location.location_name %></option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group form-group-default">
                                                        <label>Courier<span style="color:red">*</span></label>
                                                        <select class="form-control" id="select_courier" disabled>
                                                            <option value="-1">Select Courier</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                                <div class="modal-footer">
                                    <a type="button"  id="assign_courier_btn" class="btn btn-success">Ok</a>
                                    <a type="button" class="btn btn-default" data-dismiss="modal">Close</a>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="modal fade" id="success-modal_2" tabindex="-1" role="dialog" aria-labelledby="modal-success-label" data-keyboard="false" data-backdrop="static">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header state modal-success">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="modal-success-label"><i class="fa fa-user"></i>Delete Order</h4>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group-attached">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="form-group form-group-default">
                                                    Do you really want to delete the order?
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <a type="button" class="btn btn-success" order_id="0" user_type="" id="delete_order_confirm_btn" ng-click="delete_order_confirm()">Yes</a>
                                    <a type="button" class="btn btn-default" data-dismiss="modal">No</a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </form>
@endsection