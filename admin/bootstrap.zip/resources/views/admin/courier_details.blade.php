@extends('layouts.admin.dashboard')

@section('content')

<div class="pull-left">
    <div class="col-xs-12">
        <a href="{{ url('dashboard/couriers/add') }}" class="btn btn-wide btn-success" >ADD COURIER</a>
    </div>
</div>
<div class="col-sm-12" ng-controller="CourierController">
        <div class="container-fluid padding-25 sm-padding-10">
            <div class="panel panel-transparent clearfix">
                 <form role="form" name="CourierRequestForm" id="CourierRequestForm" novalidate>
                    <div class="col-sm-6">
                        <div class="row">
                            <h3 class="text text-success">Personal Information</h3>
                            <div class="col-sm-6">
                                <div class="form-group form-group-default">
                                    <label>First Name <span style="color:red">*</span></label>
                                    <input type="text" class="form-control" value="{{ $courier[0]->first_name }}" name="first_name" ng-required="true" >
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group form-group-default">
                                    <label>Last Name <span style="color:red">*</span></label>
                                    <input type="text" class="form-control" value="{{ $courier[0]->last_name }}" name="last_name"  ng-required="true" >
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group form-group-default">
                                    <label>Father's Name</label>
                                    <input type="text" class="form-control" value="{{ $courier[0]->father_name }}" name="father_name">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group form-group-default">
                                    <label>Mother's Name</label>
                                    <input type="text" class="form-control" value="{{ $courier[0]->mother_name }}" name="mother_name" >
                                </div>
                            </div>
                            <div class="col-sm-12" id="locationField">
                                <div class="form-group form-group-default">
                                    <label>Email</label>
                                    <input type="text" class="form-control" value="{{ $courier[0]->email }}" name="email">
                                </div>
                            </div>
                            <div class="col-sm-6" id="locationField">
                                <div class="form-group form-group-default">
                                    <label>Date of Birth</label>
                                    <input type="text" class="form-control default_datetimepicker" value="{{ $courier[0]->dob }}" name="dob" ng-required="true">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group form-group-default">
                                    <label>Religion</label>
                                    <select class="form-control"  name="religion">
                                        <option value="Islam">Islam</option>
                                        <option value="Cristian">Cristian</option>
                                        <option value="Hindu">Hindu</option>
                                        <option value="Bhuddist">Bhuddist</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group form-group-default">
                                    <label>Nationality</label>
                                    <input type="text" class="form-control" value="{{ $courier[0]->nationality }}" name="nationality">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group form-group-default">
                                    <label>National ID Number</label>
                                    <input type="text" class="form-control" value="{{ $courier[0]->national_id_number }}" name="national_id_number" >
                                </div>
                            </div>
                            <div class="col-sm-6" id="locationField">
                                <div class="form-group form-group-default">
                                    <label>Blood Group</label>
                                    <select class="form-control"  name="blood_group">
                                        <option value="A+">A+</option>
                                        <option value="B+">B+</option>
                                        <option value="O+">O+</option>
                                        <option value="AB+">AB+</option>
                                        <option value="B-">B-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6" id="locationField">
                                <div class="form-group form-group-default">
                                    <label>Gender</label>
                                    <select class="form-control"  name="gender">
                                        <option value="M">Male</option>
                                        <option value="F">Female</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6" id="locationField">
                                <div class="form-group form-group-default">
                                    <label>Maritial Status</label>
                                    <input type="text" class="form-control" value="{{ $courier[0]->maritial_status }}" name="maritial_status">
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <h3 class="text text-success">Contact Number</h3>
                            <div class="col-sm-4">
                                <div class="form-group form-group-default">
                                    <label>Home <span style="color:red">*</span></label>
                                    <input type="text" class="form-control" value="{{ $courier[0]->contact_no_home }}" name="contact_no_home" ng-required="true" >
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group form-group-default">
                                    <label>Work <span style="color:red">*</span></label>
                                    <input type="text" class="form-control" value="{{ $courier[0]->contact_no_work }}" name="contact_no_work" ng-required="true" >
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group form-group-default">
                                    <label>Other</label>
                                    <input type="text" class="form-control" value="{{ $courier[0]->contact_no_other }}" name="contact_no_other">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <h3 class="text text-success">Attach Documents</h3>
                            <div class="col-sm-12">
                                <div class="form-group form-group-default">
                                    <label>Photo</label>
                                    @if($courier[0]->picture != '')
                                        <a href="{{ url('uploads/'.$courier[0]->picture) }}" target="_blank">View</a>
                                    @else
                                        Not attached
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group form-group-default">
                                    <label>Birth Certificate</label>
                                    @if($courier[0]->dob_doc != '')
                                        <a href="{{ url('uploads/'.$courier[0]->dob_doc) }}" target="_blank">View</a>
                                    @else
                                        Not attached
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group form-group-default">
                                    <label>Utility Bills</label>
                                    @if($courier[0]->national_id_number_doc != '')
                                        <a href="{{ url('uploads/'.$courier[0]->national_id_number_doc) }}" target="_blank">View</a>
                                    @else
                                        Not attached
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group form-group-default">
                                    <label>National ID Card</label>
                                    @if($courier[0]->address_verification_doc != '')
                                        <a href="{{ url('uploads/'.$courier[0]->address_verification_doc) }}" target="_blank">View</a>
                                    @else
                                        Not attached
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group form-group-default">
                                    <label>CV</label>
                                    @if($courier[0]->cv != '')
                                        <a href="{{ url('uploads/'.$courier[0]->cv) }}" target="_blank">View</a>
                                    @else
                                        Not attached
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>

                     <?php
                        $permanent_address = unserialize($courier[0]->permanent_address);
                        $present_address = unserialize($courier[0]->present_address);
                     ?>
                     <div class="col-sm-6">
                         <div class="row" id="test2">
                             <h3 class="text text-success">Present Address</h3>
                             <div class="col-sm-12">
                                 <div class="form-group form-group-default">
                                     <label>Street</label>
                                         {{ $present_address['street']}}
                                 </div>
                             </div>
                             {{--<div class="col-sm-6">
                                 <div class="form-group form-group-default">
                                     <label>Town</label>
                                     <input type="text" class="form-control" value="{{ $present_address['town']}}" name="present_address[town]" >
                                 </div>
                             </div>
                             <div class="col-sm-6">
                                 <div class="form-group form-group-default">
                                     <label>District</label>
                                     <input type="text" class="form-control" value="{{ $present_address['district']}}" name="present_address[district]" >
                                 </div>
                             </div>
                             <div class="col-sm-6">
                                 <div class="form-group form-group-default">
                                     <label>Post Code</label>
                                     <input type="text" class="form-control"  value="{{ $present_address['post_code']}}"name="present_address[post_code]" >
                                 </div>
                             </div>
                             <div class="col-sm-6">
                                 <div class="form-group form-group-default">
                                     <label>Country</label>
                                     <input type="text" class="form-control" value="{{ $present_address['country']}}" name="present_address[country]">
                                 </div>
                             </div>--}}
                         </div>

                     </div>
                     <div class="col-sm-6">
                         <div class="row">
                             <h3 class="text text-success">Permanent Address</h3>
                             <div class="col-sm-12">
                                 <div class="form-group form-group-default">
                                     <label>Thana</label>
                                         {{ $permanent_address['thana']}}
                                </div>
                             </div>
                             {{--<div class="col-sm-6">
                                 <div class="form-group form-group-default">
                                     <label>Post Office</label>
                                     <input type="text" class="form-control" value="{{ $permanent_address['post_office']}}" name="permanent_address[post_office]">
                                 </div>
                             </div>
                             <div class="col-sm-6">
                                 <div class="form-group form-group-default">
                                     <label>Village</label>
                                     <input type="text" class="form-control" value="{{ $permanent_address['village']}}" name="permanent_address[village]">
                                 </div>
                             </div>
                             <div class="col-sm-6">
                                 <div class="form-group form-group-default">
                                     <label>District</label>
                                     <input type="text" class="form-control" value="{{ $permanent_address['district']}}" name="permanent_address[district]">
                                 </div>
                             </div>--}}
                         </div>

                     </div>

                     <div class="col-sm-6">
                         <div class="row" id="test2">
                             <h3 class="text text-success">References</h3>
                             <div class="col-sm-12">
                                 <div>
                                    <table class="table table-striped">
                                        <thead ng-if="references.length">
                                            <tr>
                                                <th>Name</th>
                                                <th>Company</th>
                                                <th>Designation</th>
                                                <th>Email</th>
                                                <th>Phone</th>
                                            </tr>
                                        </thead>
                                        <tr ng-repeat="reference in references">
                                            <td><% reference[0] %></td>
                                            <td><% reference[1] %></td>
                                            <td><% reference[2] %></td>
                                            <td><% reference[3] %></td>
                                            <td><% reference[4] %></td>
                                        </tr>
                                    </table>
                                 </div>
                                 <button class="btn btn-danger" data-target="#modalSlideUp" data-toggle="modal">ADD Reference</button>
                             </div>
                         </div>
                     </div>
                     <input type="hidden" id="experiences" name="experiences">
                     <div class="col-sm-6">
                         <div class="row" id="test2">
                             <h3 class="text text-success">Experiences</h3>
                             <div class="col-sm-12">
                                 <div>
                                     <table class="table table-striped">
                                         <thead ng-if="experiences.length">
                                         <tr>
                                             <th>Company</th>
                                             <th>Designation</th>
                                             <th>Start Date</th>
                                             <th>Start Date</th>
                                         </tr>
                                         </thead>
                                         <tr ng-repeat="experience in experiences">
                                             <td><% experience[0] %></td>
                                             <td><% experience[1] %></td>
                                             <td><% experience[2] %></td>
                                             <td><% experience[3] %></td>
                                         </tr>
                                     </table>
                                 </div>
                                 <button class="btn btn-danger" data-target="#modalSlideUpExperience" data-toggle="modal">ADD Experience</button>
                             </div>
                         </div>
                     </div>
                     <div class="col-sm-6">
                         <div class="row" id="test2">
                             <h3 class="text text-success">Remarks</h3>
                             <div class="col-sm-12">
                                 <div class="form-group form-group-default">
                                         {{ $courier[0]->comments }}
                                 </div>
                             </div>
                         </div>
                     </div>
                  </form>

            </div>

        </div>
    <div class="modal fade stick-up" id="modalSlideUp" tabindex="-1" role="dialog" aria-hidden="false">
        <div class="modal-dialog ">
            <div class="modal-content-wrapper">
                <div class="modal-content">
                    <div class="modal-header clearfix text-left">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="pg-close fs-14"></i>
                        </button>
                        <h5>Reference <span class="semi-bold">INFORMATION</span></h5>
                        <p class="p-b-10">We need client information inorder to process the order</p>
                    </div>
                    <form name="reference_form" novalidate>
                        <div class="modal-body">
                                <div class="form-group-attached">

                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group form-group-default">
                                                <label>Name <span style="color:red">*</span></label>
                                                <input type="text" class="form-control" name="referee_name" ng-model="referee.referee_name" ng-required="true" ng-model-options="{updateOn: 'blur'}">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group form-group-default">
                                                <label>Company</label>
                                                <input type="text" class="form-control" name="referee_company" ng-model="referee.referee_company">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group form-group-default">
                                                <label>Designation</label>
                                                <input type="text" class="form-control" name="referee_designation" ng-model="referee.referee_designation">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group form-group-default">
                                                <label>Email Address</label>
                                                <input type="text" class="form-control" ng-model="referee.referee_email" name="referee_email">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group form-group-default">
                                                <label>Contact Number</label>
                                                <input type="text" class="form-control" ng-model="referee.referee_contact" >
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-sm-4 m-t-10 sm-m-t-10 pull-right">
                                                <a class="btn btn-primary btn-block m-t-5" ng-click="add_referee()" ng-disabled="reference_form.$invalid">Add</a>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
    <div class="modal fade stick-up" id="modalSlideUpExperience" tabindex="-1" role="dialog" aria-hidden="false">
        <div class="modal-dialog ">
            <div class="modal-content-wrapper">
                <div class="modal-content">
                    <div class="modal-header clearfix text-left">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="pg-close fs-14"></i>
                        </button>
                        <h5>Experience <span class="semi-bold">INFORMATION</span></h5>
                        <p class="p-b-10">We need client information inorder to process the order</p>
                    </div>
                    <form name="experience_form" novalidate>
                        <div class="modal-body">
                                <div class="form-group-attached">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group form-group-default">
                                                <label>Company <span style="color:red">*</span></label>
                                                <input type="text" class="form-control" name="company" ng-model="exp.company" ng-required="true" ng-model-options="{updateOn: 'blur'}">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group form-group-default">
                                                <label>Designation</label>
                                                <input type="text" class="form-control" name="designation" ng-model="exp.designation">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group form-group-default">
                                                <label>Start Date</label>
                                                <input type="text" class="form-control default_datetimepicker" name="start_date" ng-model="exp.start_date">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group form-group-default">
                                                <label>End Date</label>
                                                <input type="text" class="form-control default_datetimepicker" ng-model="exp.end_date" name="end_date">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-sm-4 m-t-10 sm-m-t-10 pull-right">
                                                <a class="btn btn-primary btn-block m-t-5" ng-click="add_experience()" ng-disabled="experience_form.$invalid">Add</a>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>

</div>


@endsection
