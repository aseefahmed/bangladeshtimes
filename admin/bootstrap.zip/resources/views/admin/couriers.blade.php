@extends('layouts.admin.dashboard')


@section('content')

    <div class="pull-left">
        <div class="col-xs-12">
            <a href="{{ url('dashboard/couriers/add') }}" class="btn btn-wide btn-success" >ADD COURIER</a>
        </div>
    </div>
    <div class="col-sm-12" ng-controller="CourierController" ng-init="loadCouriersList()">
        <div class="container-fluid padding-25 sm-padding-10">
            <div class="panel panel-transparent clearfix">
                <table id="responsive-table" class="data-table table table-striped table-hover responsive nowrap" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>Name </th>
                        <th>Father's Name</th>
                        <th>Mother's Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Gender</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($couriers as $courier)
                        <tr>
                            <td>{{ $courier->first_name }} {{ $courier->last_name }}</td>
                            <td>{{ $courier->father_name }}</td>
                            <td>{{ $courier->mother_name }}</td>
                            <td>{{ $courier->email }}</td>
                            <td>{{ $courier->contact_no_work }}</td>
                            <td>
                                @if($courier->gender == 'M')
                                    Male
                                @else
                                    Female
                                @endif
                            </td>
                            <td><a href="{{ url('dashboard/courier/'.$courier->id) }}" class="btn btn-primary"><i class="fa fa-eye"></i> View</a></td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>

        </div>
    </div>


@endsection
