<?php $__env->startSection('content'); ?>
    <div class="alert alert-success fade in text-center">
        <h1>Orders List</h1>
    </div>

    <div class="col-sm-12" ng-controller="OrderController" ng-init="loadOrdersList('<?php echo e($order_status); ?>')">
        <?php if(Auth::user()->id == 1): ?>
            <div class="pull-left">
                <div class="col-xs-12">
                    <a href="<?php echo e(url('dashboard/orders/add')); ?>" class="btn btn-wide btn-success" >ADD ORDER</a>
                </div>
            </div>
        <?php endif; ?>


            <div class="container-fluid padding-25 sm-padding-10">
            <div class="clearfix"></div>
            <div class="panel panel-transparent clearfix">
                <div class="panel-heading">

                </div>
                <div class="panel-body clearfix">

                    <table class="table table-hover demo-table-dynamic table-responsive-block" id="responsive-table">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Sender</th>
                            <th>Reciever</th>
                            <th>Shipping Method</th>
                            <th>Pickup Date</th>
                            <th>ETD</th>
                            <th>Status</th>
                            <th class="text-right">Acttion</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php foreach($orders as $order): ?>
                            <tr>
                                <td><?php echo e($order->id); ?></td>
                                <td><?php echo e($order->sender_name); ?></td>
                                <td><?php echo e($order->reciever_name); ?></td>
                                <td>
                                    <?php if($order->shipping_time < 20): ?>
                                        Express
                                    <?php else: ?>
                                        Regular
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(date_format(date_create($order->pickup_date), 'Y-m-d g:i A')); ?></td>
                                <td>
                                    <?php
                                    $date = date_create($order->pickup_date);
                                    date_add($date, date_interval_create_from_date_string($order->shipping_time.' hours'));
                                    echo date_format($date, 'Y-m-d g:i A');
                                    ?>
                                </td>
                                <td>
                                    <?php if($order->flag == 0): ?>
                                        <strong class="badge x-danger">Pending</strong>
                                    <?php elseif($order->flag == 1): ?>
                                        <strong class="badge x-success">Approved</strong>
                                    <?php elseif($order->flag == 2): ?>
                                        <strong class="badge x-warning">Picked Up</strong>
                                    <?php elseif($order->flag == 3): ?>
                                        <strong class="badge x-warning">Dropped Of</strong>
                                    <?php elseif($order->flag == 4): ?>
                                        <strong class="badge x-warning">Transferred</strong>
                                    <?php elseif($order->flag == 5): ?>
                                        <strong class="badge x-warning">On Hold</strong>
                                    <?php elseif($order->flag == 9): ?>
                                        <strong class="badge x-warning">Delivered</strong>
                                    <?php elseif($order->flag == 10): ?>
                                        <strong class="badge x-warning">Returned</strong>
                                    <?php endif; ?>
                                </td>
                                <td class="text-right">

                                    <a  href="<?php echo e(url('dashboard/order/'.$order->id)); ?>" class="btn btn-success"><i class="fa fa-eye"></i> View</a>
                                    <?php if(Auth::user()->role == 9): ?>
                                        <?php if(is_assigned($order->id, Auth::user()->id) == 0): ?>
                                            <a ng-click="deny_order(<?php echo $order->id;?>)" class="btn btn-danger"><i class="fa fa-bell-o"></i> Deny</a>
                                            <a ng-click="accept_order(<?php echo $order->id;?>)" class="btn btn-info"><i class="fa fa-anchor"></i> Accept</a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if(($order->flag != 0 && $order->assigned_courier == 0) ||  ($order->flag == 3 && findBranchManager($order->location_id) == Auth::user()->id)): ?>
                                        <a order_id="[[ order.id ]]" ng-click="openModal(<?php echo e($order->id); ?>)" class="btn btn-danger"><i class="fa fa-user"></i> Assign to Courier </a>
                                    <?php elseif($order->assigned_courier != 0): ?>
                                        <?php if($order->assigned_courier != Auth::user()->id): ?>
                                            <a order_id="[[ order.id ]]" ng-click="openModal(<?php echo e($order->id); ?>)" class="btn btn-warning"><i class="fa fa-user"></i> Assigned to <?php echo e($order->c_first_name); ?></a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->role == 1): ?>
                                        <a ng-click="delete_order(<?php echo $order->id;?>)" class="btn btn-danger"><i class="fa fa-trash"></i> Delete</a>
                                    <?php endif; ?>
                               </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    <!-- Modal -->
                    <div class="modal fade" id="success-modal" tabindex="-1" role="dialog" aria-labelledby="modal-success-label" data-keyboard="false" data-backdrop="static">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header state modal-success">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="modal-success-label"><i class="fa fa-user"></i>Assign To Courier</h4>
                                </div>
                                <div class="modal-body">

                                        <div class="form-group-attached">
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div class="form-group form-group-default">
                                                        <label>Location<span style="color:red">*</span></label>
                                                        <select class="form-control" order_id="[[ $order_id ]]" id="select_location">
                                                            <option value="0">Select Location</option>
                                                            <option ng-repeat="location in locations" value="[[ location.id ]]">[[ location.location_name ]]</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group form-group-default">
                                                        <label>Courier<span style="color:red">*</span></label>
                                                        <select class="form-control" id="select_courier" disabled>
                                                            <option value="-1">Select Courier</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                                <div class="modal-footer">
                                    <a type="button"  id="assign_courier_btn" class="btn btn-success">Ok</a>
                                    <a type="button" class="btn btn-default" data-dismiss="modal">Close</a>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="modal fade" id="success-modal_2" tabindex="-1" role="dialog" aria-labelledby="modal-success-label" data-keyboard="false" data-backdrop="static">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header state modal-success">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="modal-success-label"><i class="fa fa-user"></i>Delete Order</h4>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group-attached">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="form-group form-group-default">
                                                    Do you really want to delete the order?
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <a type="button" class="btn btn-success" order_id="0" user_type="" id="delete_order_confirm_btn" ng-click="delete_order_confirm()">Yes</a>
                                    <a type="button" class="btn btn-default" data-dismiss="modal">No</a>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="modal fade" id="success-modal_3" tabindex="-1" role="dialog" aria-labelledby="modal-success-label" data-keyboard="false" data-backdrop="static">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header state modal-success">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="modal-success-label"><i class="fa fa-user"></i>Deny Order</h4>
                                </div>
                                <div class="modal-body">
                                    <form role="form" name="orderDenyForm" id="orderDenyForm" novalidate>
                                    <?php echo e(csrf_field()); ?>

                                        <div class="form-group-attached">
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div class="form-group form-group-default">
                                                        Do you really want to deny this assignment?
                                                    </div>
                                                    <div>
                                                        <select id="deny_reason" style="border: 1px red solid;" ng-required="true" ng-model="deny_reason" name="deny_reason" class="form-control">
                                                            <option value="">Choose Denying Reason</option>
                                                            <option value="Out of City">Out of City</option>
                                                            <option value="On Holiday">On Holiday</option>
                                                            <option value="Absense">Absense</option>
                                                            <option value="Overloaded">Overloaded</option>
                                                            <option value="Rough Weather">Rough Weather</option>
                                                            <option value="Hours/Schedule Unacceptable">Hours/Schedule Unacceptable</option>
                                                            <option value="Not My Job">Not My Job</option>
                                                            <option value="Not in My Area">Not in My Area</option>
                                                            <option value="Political Violence">Political Violence</option>
                                                            <option value="Feeling Sick">Feeling Sick</option>
                                                            <option value="Cycle Trouble">Cycle Trouble</option>
                                                            <option value="Got Accident ">Got Accident </option>
                                                            <option value="Family Illness">Family Illness</option>
                                                            <option value="Injured and Unable to Work">Injured and Unable to Work</option>
                                                            <option value="Family Emergency"></option>
                                                            <option value="Other">Other</option>
                                                        </select>
                                                    </div>
                                                    <br>
                                                    <div class="form-group form-group-default" style="display:none" id="deny_reason_2" >
                                                        <textarea ng-model="deny_reason_2_details" name="deny_reason_2_details"  id="deny_reason_2_details" class="form-control" placeholder="Please mention the reason for deny."></textarea>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <a type="button" class="btn btn-success" data-ng-disabled="orderDenyForm.$invalid" order_id="0" courier_id="<?php echo e(Auth::user()->id); ?>" user_type="" id="deny_order_confirm_btn" ng-click="deny_order_confirm()">Yes</a>
                                    <a type="button" class="btn btn-default" data-dismiss="modal">No</a>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="modal fade" id="success-modal_4" tabindex="-1" role="dialog" aria-labelledby="modal-success-label" data-keyboard="false" data-backdrop="static">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header state modal-success">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="modal-success-label"><i class="fa fa-user"></i>Accept Order</h4>
                                </div>
                                <div class="modal-body">
                                    <form role="form" name="orderAcceptForm" id="orderAcceptForm" novalidate>
                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-group-attached">
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div class="form-group form-group-default">
                                                        Do you really want to accept this assignment?
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <a type="button" class="btn btn-success"  order_id="0" courier_id="<?php echo e(Auth::user()->id); ?>" user_type="" id="accept_order_confirm_btn" ng-click="accept_order_confirm()">Yes</a>
                                    <a type="button" class="btn btn-default" data-dismiss="modal">No</a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>