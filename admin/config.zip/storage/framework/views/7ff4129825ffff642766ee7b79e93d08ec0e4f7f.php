<?php $__env->startSection('content'); ?>
<?php /*
<div class="pull-left" style="padding-left:15px;">
  <div class="col-xs-12"> <a href="<?php echo e(url('dashboard/clients/list')); ?>" class="btn btn-wide btn-success" >USERS LIST</a> </div>
</div>
*/ ?>

<div class="col-sm-12" ng-controller="ClientController" >
  <div class="container-fluid padding-25 sm-padding-10">

    <div class="panel panel-transparent clearfix">

      <div class="panel-header">
        <h5 class="panel-title">Details Update Form</h5>
      </div>

      <form id="userDetails">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="user_id" value="<?php echo e($user[0]->id); ?>">
        <input type="hidden" name="user_type" value="<?php echo e($user_type); ?>">

        <div class="panel-content">
          <div class="alert alert-success fade in" style="display: none;" id="success_div">
            <strong>Success!</strong> You have successfully updated the information
          </div>
          <div class="alert alert-danger fade in" style="display: none;" id="failure_div">
            <strong>Error!</strong> Operation Faild
          </div>

          <div class="p-info">
            <ul>
              <li><span>Employee Name</span>
                <?php if($user_type == 'clients'): ?>
                    <input type="text" class="form-control" value="<?php echo e($user[0]->name); ?>" name="name">
                <?php elseif($user_type == 'employees'): ?>
                  <input type="text" class="form-control" value="<?php echo e($user[0]->first_name); ?>" name="first_name" placeholder="First Namae">
                  <input type="text" class="form-control" value="<?php echo e($user[0]->last_name); ?>" name="last_name" placeholder="Last Namae">

                <?php endif; ?>
              </li>
              <li>
                <?php if($user_type == 'clients'): ?>
                  <span>Account Type</span>
                  <select class="form-control"  name="account_type">
                    <option value="1" <?php if($user[0]->account_type == 1){echo "selected";} ?>>Individual</option>
                    <option value="2" <?php if($user[0]->account_type == 2){echo "selected";} ?>>Corporate</option>
                    <option value="3" <?php if($user[0]->account_type == 3){echo "selected";} ?>>Government</option>
                  </select>
                <?php elseif($user_type == 'employees'): ?> <span>Role</span>
                <select class="form-control"  name="role" >
                  <?php foreach($roles as $role): ?>
                    <option value="<?php echo e($role->id); ?>" <?php if($user[0]->role == $role->id){echo "selected";} ?>><?php echo e($role->name); ?></option>
                  <?php endforeach; ?>
                </select>
                <?php endif; ?>
              </li>
            </ul>
            <ul>
              <li><span>Email Address</span> <input type="text" class="form-control" value="<?php echo e($user[0]->email); ?>" name="email"></li>
            </ul>
          </div>
          <a class="btn btn-danger" id="edit_user"><i class="fa fa-pencil"></i> Update Information</a>
        </div>
      </form>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>