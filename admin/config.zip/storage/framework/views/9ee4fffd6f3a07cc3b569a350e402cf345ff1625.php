<option value="">Select Upazilla</option>
<?php foreach($upazillas as $upazilla): ?>
    <option value="<?php echo e($upazilla->id); ?>"><?php echo e($upazilla->bn_name); ?></option>
<?php endforeach; ?>