<?php $__env->startSection('content'); ?>
<div class="pull-left" style="padding-left:15px;">
  <div class="col-xs-12"> <a href="<?php echo e(url('dashboard/couriers/add')); ?>" class="btn btn-wide btn-success" >ADD COURIER</a> </div>
</div>
<div class="col-sm-12" ng-controller="CourierController" ng-init="loadCouriersList()">
  <div class="container-fluid padding-25 sm-padding-10">
    <div class="panel panel-transparent clearfix">
     <div class="panel-body clearfix">
      <table id="responsive-table" class="data-table table table-striped table-hover responsive nowrap" cellspacing="0" width="100%">
        <thead>
          <tr>
            <th>Name </th>
            <th>Email</th>
            <th>Phone</th>
            <th>Gender</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
        
        <?php foreach($couriers as $courier): ?>
        <tr>
          <td><?php echo e($courier->first_name); ?> <?php echo e($courier->last_name); ?></td>
          <td><?php echo e($courier->email); ?></td>
          <td><?php echo e($courier->contact_no_work); ?></td>
          <td> <?php echo e($courier->gender); ?> </td>
          <td> 
          	<?php if($courier->status == 'Pending'): ?>
            	<span class="badge x-danger"><?php echo e($courier->status); ?> </span>
            <?php elseif($courier->status == 'Processing'): ?>
            	<span class="badge x-warning"><?php echo e($courier->status); ?> </span>
            <?php elseif($courier->status == 'Confirmed'): ?>
            	<span class="badge x-success"><?php echo e($courier->status); ?> </span>
            <?php elseif($courier->status == 'Inactive'): ?>
            	<span class="badge"><?php echo e($courier->status); ?> </span>
			<?php elseif($courier->status == 'Deleted'): ?>
            	<span class="badge x-danger"><?php echo e($courier->status); ?> </span>                
            <?php endif; ?>
          </td>
          <td>
              <a href="<?php echo e(url('dashboard/courier/'.$courier->id)); ?>" class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="View"><i class="fa fa-eye"></i></a> 
              <a href="<?php echo e(url('dashboard/courier/edit/'.$courier->id)); ?>" class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-pencil-square-o"></i></a> 
              <a href="<?php echo e(url('dashboard/courier/delete/'.$courier->id)); ?>" class="btn btn-danger" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash-o"></i></a>
          </td>
        </tr>
        <?php endforeach; ?>
          </tbody>        
      </table>
    </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>