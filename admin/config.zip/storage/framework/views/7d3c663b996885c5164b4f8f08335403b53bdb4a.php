<option value="">Select Courier</option>
<?php foreach($couriers as $courier): ?>
    <option value="<?php echo e($courier->id); ?>"><?php echo e($courier->first_name); ?> <?php echo e($courier->last_name); ?></option>
<?php endforeach; ?>