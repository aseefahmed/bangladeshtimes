<?php $__env->startSection('content'); ?>
<?php /*<div class="pull-left" style="padding-left:15px;">
  <div class="col-xs-12"> <a href="<?php echo e(url('dashboard/clients/list')); ?>" class="btn btn-wide btn-success" >USERS LIST</a> </div>
</div>*/ ?>
<?php if(Auth::user()->role == 1): ?>
  <div class="pull-left" style="padding-left:15px;">
    <div class="col-xs-12">
      <a href="<?php echo e(url('password/change/'.$user[0]->id)); ?>" class="btn btn-wide btn-success" >Change Password</a>
    </div>
  </div>
<?php endif; ?>
<div class="col-sm-12">
  <div class="container-fluid padding-25 sm-padding-10">
    <div class="panel panel-transparent clearfix">
      <div class="panel-header">
        <h5 class="panel-title">Details Information</h5>
      </div>
      <div class="panel-content">
        <div class="p-info">
          <ul>
            <li><span>Employee Name</span> <?php if($user_type == 'clients'): ?>
              <p><?php echo e($user[0]->name); ?></p>
              <?php elseif($user_type == 'employees'): ?>
              <p><?php echo e($user[0]->first_name); ?> <?php echo e($user[0]->last_name); ?></p>
              <?php endif; ?> </li>
            <li> <?php if($user_type == 'clients'): ?> <span>Account Type</span> <?php if($user[0]->account_type == 1): ?>
              <p>Individual</p>
              <?php elseif($user[0]->account_type == 2): ?>
              <p>Government</p>
              <?php elseif($user[0]->account_type == 3): ?>
              <p>Corporate</p>
              <?php endif; ?>
              <?php elseif($user_type == 'employees'): ?> <span>Role</span>
              <p><?php echo e(ucwords($user[0]->role_name)); ?></p>
              <?php endif; ?> </li>
          </ul>
          <ul>
            <li><span>Email Address</span> <?php echo e($user[0]->email); ?></li>
            <li><span>Created At</span> <?php echo e(date_format(date_create($user[0]->created_at), 'dS M, Y')); ?></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>