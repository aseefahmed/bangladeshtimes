<?php $__env->startSection('content'); ?>
    <div class="content sm-gutter" ng-controller="LocationController" ng-init="loadLocationsList()">
        <div class="container-fluid padding-25 sm-padding-10">
            <div class="panel panel-transparent clearfix">
                <div class="panel-heading">
                    <div class="pull-left">
                        <div class="col-xs-12">
                            <button class="btn btn-primary btn-lg pull-right" data-target="#modalSlideUp" data-toggle="modal">ADD LOCATION</button>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="panel-body clearfix">
                    <div class="row col-sm-2 clearfix">
                        <input type="text" class="form-control" ng-model="search_filter" placeholder="Search">
                    </div>

                    <table class="table table-hover demo-table-dynamic table-responsive-block" id="tableWithDynamicRows">
                        <thead>
                        <tr>
                            <th>Location Name </th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                            <tr ng-if="locations.length == 0">
                                <td colspan="3">No Data Available.</td>
                            </tr>
                            <tr ng-repeat="location in locations">
                                <td><% location.location_name %> </td>
                                <td><a href="view/<% location.id %>" class="btn btn-primary">View</a></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="modal fade stick-up" id="modalSlideUp" tabindex="-1" role="dialog" aria-hidden="false">
            <div class="modal-dialog ">
                <div class="modal-content-wrapper">
                    <div class="modal-content">
                        <div class="modal-header clearfix text-left">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="pg-close fs-14"></i>
                            </button>
                            <h5>LOCATION <span class="semi-bold">INFORMATION</span></h5>
                            <p class="p-b-10">We need client information inorder to process the order</p>
                        </div>
                        <div class="modal-body">
                            <form role="form" name="locationForm" novalidate>
                                <div class="form-group-attached">

                                    <div class="row">
                                        <div class="col-sm-12" ng-if="msg != ''">
                                            <label><span style="color:red"><% msg %></span></label>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group form-group-default">
                                                <label>Location Name <span style="color:red">*</span></label>
                                                <input type="text" class="form-control" name="location_name" ng-model="location.location_name" ng-required="true" ng-model-options="{updateOn: 'blur'}">
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </form>
                            <div class="row">
                                <div class="col-sm-4 m-t-10 sm-m-t-10 pull-right">
                                    <a class="btn btn-primary btn-block m-t-5" ng-disabled="userRegistrationForm.$invalid" ng-click="addLocation(locationForm)">ADD</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>