<?php $__env->startSection('content'); ?>


<div class="wrap" ng-app="myApp" ng-controller="LoginController">
    <div class="col-sm-4">&nbsp;</div>
    <div class="col-md-4">
        <h4 class="section-subtitle"><b>Change</b> Password  </h4>
        <div class="panel">
            <div class="panel-content">
                <div class="row">
                    <div class="col-md-12">
                        <form id="PasswordChangeForm" name="PasswordChangeForm">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="<?php echo e($id); ?>">
                            <div class="form-group">
                                <label for="email">Email Address</label>
                                <input type="text" class="form-control" value="<?php echo e($email); ?>" disabled>
                            </div>
                            <div class="form-group">
                                <label for="email">Current Password</label>
                                <input type="password" class="form-control" id="old_password" name="old_password" placeholder="Current Password" ng-model="old_password" ng-requiredc="true">
                            </div>
                            <div class="form-group">
                                <label for="password">New Password</label>
                                <input type="password" class="form-control" id="new_password" name="new_password" placeholder="New Password" ng-model="new_password" ng-requiredc="true">
                            </div>
                            <div class="form-group">
                                <label for="password">Retype Password</label>
                                <input type="password" class="form-control" name="retype_password"  id="retype_password" placeholder="Type Again" ng-model="retype_password">
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary btn-block " id="change_password_id">Change Password</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-4">&nbsp;</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>