<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'first_name' => 'Aseef111',
            'last_name' => 'Ahmed',
            'email' => 'aseefahmed11@gmail.com',
            'password' => Hash::make('admin123'),
            'role' => '1'

        ]);
    }
}
