<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShipmentPurpose extends Model
{
    //
}
