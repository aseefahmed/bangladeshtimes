<?php

use App\Order;

function newOrders()
{
    $data = Order::take(5)->orderBy('id', 'desc')->get();
    return $data;
}

function isCourierInThisLocation($loc_id, $courier_id)
{
    $data = DB::table('courier_locations')->where('location_id', $loc_id)->where('courier_id', $courier_id)->count();
    return $data;
}

function isCourierGotCycle($courier_id)
{
    $data = DB::table('cycles')->where('courier_id', $courier_id)->where('flag', 1)->count();
    return $data;
}

function isOrderDenied($order_id, $courier_id)
{
    $data = DB::table('order_statuses')->where('order_id', $order_id)->where('courier_id', $courier_id)->where('status_type', 4)->orWhere('status_type', 3)->count();
    return $data;
}

function isOrderAccepted($order_id, $courier_id)
{
    $data = DB::table('order_statuses')->where('order_id', $order_id)->where('courier_id', $courier_id)->where('status_type', 4)->orWhere('status_type', 3)->count();
    return $data;
}

function findLocationDetails($location_id)
{
    return $data = DB::table('locations')->where('id', $location_id)->get();
}

function is_assigned($order_id, $user_id)
{
    return $count = DB::table('order_statuses')->where('order_id', $order_id)->where('courier_id', $user_id)->where('status_type', 3)->orWhere('status_type', 4)->count();
}

function findBranchManager($location_id)
{
    $manager = DB::table('locations')->where('id', $location_id)->get();
    return $manager[0]->manager_id;
}