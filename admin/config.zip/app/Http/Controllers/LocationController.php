<?php

namespace App\Http\Controllers;

use App\Courier;
use App\CourierLocation;
use App\Cycle;
use App\Location;
use App\User;
use Illuminate\Http\Request;

use App\Http\Requests;
use Illuminate\Support\Facades\DB;

class LocationController extends Controller
{
    public function fetchLocationsList()
    {
        $data['locations'] = DB::table('locations')->join('users', 'users.id', '=', 'locations.manager_id')->select('locations.*', 'users.first_name', 'users.last_name')->get();
        $data['users'] = User::get();
        return view('admin.locations', $data);
    }

    public function loadLocations()
    {
        $data['locations'] = Location::where('flag', 1)->get();
        return $data;
    }

    public function deleteLocation($id)
    {
        DB::table('locations')->where('id', $id)->update(
            [
                'flag' => 0
            ]
        );
    }

    public function updateLocation(Request $request)
    {
        $location = DB::table('locations')->where('id', $request->id)->update([
            'location_name' => $request->location_name,
            'address' => $request->address,
            'manager_id' => $request->contact_name,
            'contact_number' => $request->contact_number,
        ]);
    }
    public function updateCycle(Request $request)
    {
        $cycle = Cycle::find($request->id);
        $cycle->bicycle_number = $request->cycle_number ;
        $cycle->given_date = $request->given_date ;
        $cycle->comments = $request->comments ;
        if($request->courier_id != "")
            $cycle->courier_id = $request->courier_id ;
        $cycle->save();
    }

    public function deleteCycle($id)
    {
        DB::table('cycles')->where('id', $id)->update(
            [
                'flag' => 0
            ]
        );
    }
    public function getLocations($id)
    {
        $data['locations'] = Location::where('id', $id)->get();
        return $data;
    }
    public function getCycles($id)
    {
        $data['cycles'] = Cycle::where('id', $id)->get();
        return $data;
    }
    public function getLocationbasedCourier($id)
    {
        $data['couriers'] = DB::table('courier_locations')->leftJoin('couriers', 'couriers.id', '=', 'courier_locations.courier_id')->where('courier_locations.location_id', $id)->get();
        return view('ajax_views.couriers_list', $data);
    }

    public function loadEditLocationForm()
    {
        return view('admin.edit_location_form');
    }
    public function addLocation(Request $request)
    {
        $location = new Location();
        $location->location_name = $request->location_name;
        $location->address = $request->address;
        $location->manager_id = $request->contact_name;
        $location->contact_number = $request->contact_number;
        $location->flag = 1;
        $location->save();
    }
    public function addCycle(Request $request)
    {
        $location = new Cycle();
        $location->bicycle_number = $request->bicycle_number;
        $location->courier_id = $request->courier_id;
        $location->given_date = $request->given_date;
        $location->comments = $request->comments;
        $location->flag = 1;
        $location->save();
    }

    public function viewLocation($id)
    {
        $data['location'] = Location::where('id', $id)->get();
        $data['couriers'] = Courier::get();
        return view('admin.location_details', $data);
    }

    public function addCourierToLocation(Request $request)
    {
         $courier_location = new CourierLocation();
         $courier_location->location_id = $request->location_id;
         $courier_location->courier_id = $request->courier_id;
         $courier_location->save();
    }

    public function checkCycleNumber($number)
    {
        $data['count'] = DB::table('cycles')->where('bicycle_number', $number)->count();
        return $data;
    }
    public function fetchCyclesList()
    {
        $data['cycles'] = DB::table('cycles')->join('couriers', 'couriers.id', '=', 'cycles.courier_id')->where('flag', 1)->select('cycles.*', 'couriers.first_name as courier_first_name', 'couriers.last_name as courier_last_name')->get();
        $data['couriers'] = Courier::get();
        return view('admin.cycles', $data);
    }
    public function getLocationBasedCouriersList($loc_id)
    {
        $data['couriers'] = DB::table('courier_locations')->leftJoin('couriers', 'couriers.id', '=', 'courier_locations.courier_id')->where('courier_locations.location_id', $loc_id)->select('couriers.first_name','couriers.last_name', 'couriers.email', 'couriers.contact_no_work', 'couriers.blood_group', 'couriers.dob')->get();
        return $data;
    }
}
