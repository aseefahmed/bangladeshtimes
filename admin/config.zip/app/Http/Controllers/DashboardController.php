<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function viewDashboard()
    {
        $data['no_of_customer'] = DB::table('customers')->count();
        $data['no_of_order'] = DB::table('orders')->count();
        $data['no_of_courier'] = DB::table('couriers')->count();
        $data['no_of_order_delivered'] = DB::table('orders')->where('flag', 10)->count();
        return view('admin.dashboard', $data);
    }
}
