<!doctype html>
<html lang="en" class="fixed">


<!-- Mirrored from myiideveloper.com/helsinki/helsinki-green/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 23 Feb 2017 08:56:36 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>NRB Express</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
    <link rel="icon" type="image/png" sizes="192x192" href="favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
    <link href="{{ asset('public/css/all.css') }}" rel="stylesheet" type="text/css"/>
    <link href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
    <link href="https://cdn.datatables.net/buttons/1.2.4/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css"/>
    <link href="{{ asset('public/css/datetimepicker.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('public/plugins/bootstrap-fileinput/css/fileinput.css') }}" rel="stylesheet" type="text/css">
    <link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet"/>

    <link href="{{ asset('public/css/toaster.min.css') }}" rel="stylesheet" type="text/css"/>


    <style>
        input.submitted.ng-invalid
        {
            border:1px solid #f00;
        }
        select.submitted.ng-invalid
        {
            border:1px solid #f00;
        }
    </style>
</head>

<body ng-app="myApp">
<div class="wrap">
    <div class="page-header">
        <div class="leftside-header">
            <div class="logo">
                <a href="{{ url('/dashboard') }}" class="on-click">
                    <img alt="logo" src="{{ asset('public/img/logo.png') }}" />
                </a>
            </div>
            <div id="menu-toggle" class="visible-xs toggle-left-sidebar" data-toggle-class="left-sidebar-open" data-target="html">
                <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
            </div>
        </div>
        <div class="rightside-header">
            <div class="header-middle"></div>

            <div class="header-section hidden-xs" id="notice-headerbox">


                <div class="notice" id="alerts-notice">
                    <i class="fa fa-bell-o" aria-hidden="true"><span class="badge badge-xs badge-top-right x-danger">New</span></i>
                    <div class="dropdown-box basic">
                        <div class="drop-header">
                            <h3><i class="fa fa-bell-o" aria-hidden="true"></i> Notifications</h3>
                            <span class="badge x-danger b-rounded">New</span>
                        </div>
                        <div class="drop-content">
                            <div class="widget-list list-left-element list-sm">
                                <ul>
                                    @foreach(newOrders() as $order)
                                        <li>
                                            <a href="{{ url('dashboard/order/'.$order->id) }}">
                                                <div class="left-element"><i class="fa fa-warning color-warning"></i></div>
                                                <div class="text">
                                                    <span class="title">{{ $order->reciever_name }}</span>
                                                    <span class="subtitle">Date: {{ date_format(date_create($order->pickup_date), 'Y-m-d') }}</span>
                                                </div>
                                            </a>
                                        </li>
                                    @endforeach
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="header-separator"></div>
            </div>
            <div class="header-section" id="user-headerbox">
                <div class="user-header-wrap">
                    <div class="user-photo">
                        <img src="{{ url('public/img/profiles/1.png') }}" alt="{{ Auth::user()->first_name }} {{ Auth::user()->last_name }}" />
                    </div>
                    <div class="user-info">
                        <span class="user-name">{{ Auth::user()->first_name }} {{ Auth::user()->last_name }}</span>
                        @if(Auth::user()->role == 1)
                            <span class="user-profile">Admin</span>
                        @endif
                    </div>
                    <i class="fa fa-plus icon-open" aria-hidden="true"></i>
                    <i class="fa fa-minus icon-close" aria-hidden="true"></i>
                </div>
                <div class="user-options dropdown-box">
                    <div class="drop-content basic">
                        <ul>
                            @if(Auth::user()->role == 9)
                                <li> <a href="{{ url('dashboard/courier/'.Auth::user()->id) }}"><i class="fa fa-user" aria-hidden="true"></i> Profile</a></li>
                            @else
                                <li> <a href="#"><i class="fa fa-user" aria-hidden="true"></i> Profile</a></li>
                            @endif
                            <li> <a href="{{ url('password/change') }}"><i class="fa fa-lock" aria-hidden="true"></i> Change Password</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="header-separator"></div>
            <div class="header-section">
                <a href="{{ url('logout') }}" data-toggle="tooltip" data-placement="left" title="Logout"><i class="fa fa-sign-out log-out" aria-hidden="true"></i></a>
            </div>
        </div>
    </div>
    <div class="page-body">
        <div class="left-sidebar">
            <!-- left sidebar HEADER -->
            <div class="left-sidebar-header">
                <div class="left-sidebar-title">Navigation</div>
                <div class="left-sidebar-toggle c-hamburger c-hamburger--htla hidden-xs" data-toggle-class="left-sidebar-collapsed" data-target="html">
                    <span></span>
                </div>
            </div>
            <!-- NAVIGATION -->
            <!-- ========================================================= -->
            <div id="left-nav" class="nano">
                <div class="nano-content">
                    <nav>
                        <ul class="nav" id="main-nav">
                            <!--HOME-->
                            <li class="active-item"><a href="{{ url('/dashboard') }}"><i class="fa fa-home" aria-hidden="true"></i><span>Dashboard</span></a></li>
                            <!--UI ELEMENTENTS-->
                            @if(Auth::user()->role == 1 )
                                <li class="has-child-item close-item">
                                    <a><i class="fa fa-users" aria-hidden="true"></i><span>User Accounts</span></a>
                                    <ul class="nav child-nav level-1">
                                        <li><a href="{{ url('dashboard/clients/list') }}">Customers</a></li>
                                        <li><a href="{{ url('dashboard/employees/list') }}">Employees</a></li>
                                    </ul>
                                </li>
                            @endif
                            <!--CHARTS-->
                            <li class="has-child-item close-item">
                                <a><i class="fa fa-gift" aria-hidden="true"></i><span>Online Orders</span> </a>
                                <ul class="nav child-nav level-1">
                                    @if(Auth::user()->role == 1)
                                        <li><a href="{{ url('dashboard/orders/all/pending') }}">Pending Orders</a></li>
                                        <li><a href="{{ url('dashboard/orders/all/approved') }}">Approved Orders</a></li>
                                    @endif
                                    @if(Auth::user()->role == 9)
                                        <li><a href="{{ url('dashboard/orders/all/new') }}">New Order Requests</a></li>
                                        <li><a href="{{ url('dashboard/orders/all/active') }}">Active Ordert Request</a></li>
                                    @endif
                                    @if(Auth::user()->role == 8)
                                        <li><a href="{{ url('dashboard/orders/all/assign') }}">Assign Order</a></li>
                                    @endif
                               </ul>
                            </li>
                            <!--FORMS-->
                            @if(Auth::user()->role == 1 || Auth::user()->role == 3 )
                                <li class="has-child-item close-item">
                                    <a><i class="fa fa-user" aria-hidden="true"></i><span>Couriers </span></a>
                                    <ul class="nav child-nav level-1">
                                        <li><a href="{{ url('dashboard/couriers/all') }}">View Couriers List</a></li>
                                    </ul>
                                </li>
                            @endif
                            <!--FORMS-->
                            @if(Auth::user()->role == 1)
                                <li class="has-child-item close-item">
                                    <a><i class="fa fa-map-marker" aria-hidden="true"></i><span>Branch/Hub </span></a>
                                    <ul class="nav child-nav level-1">
                                        <li><a href="{{ url('dashboard/locations/all') }}">View Branch/Hub List</a></li>
                                    </ul>
                                </li>
                            @endif
                            <!--FORMS-->
                            @if(Auth::user()->role == 1)
                                <li class="has-child-item close-item">
                                    <a><i class="fa fa-bicycle" aria-hidden="true"></i><span>Cycles </span></a>
                                    <ul class="nav child-nav level-1">
                                        <li><a href="{{ url('dashboard/cycles/all') }}">View Cycles List</a></li>
                                    </ul>
                                </li>
                            @endif
                            <!--FORMS-->
                            @if(Auth::user()->role == 1)
                                <li class="has-child-item close-item">
                                    <a><i class="fa fa-mars-double" aria-hidden="true"></i><span>Routes </span></a>
                                    <ul class="nav child-nav level-1">
                                        <li><a href="{{ url('dashboard/routes/all') }}">View Routes List</a></li>
                                    </ul>
                                </li>
                            @endif
                            @if(Auth::user()->role == 1)
                                <li class="has-child-item close-item">
                                    <a><i class="fa fa-cog" aria-hidden="true"></i><span>Accounts Settings</span></a>
                                    <ul class="nav child-nav level-1">
                                        <li><a href="{{ url('dashboard/roles') }}">Roles</a></li>
                                        <li><a href="{{ url('dashboard/permissions') }}">Permissions</a></li>
                                    </ul>
                                </li>
                            @endif
                            @if(Auth::user()->role == 1)
                                <li class="has-child-item close-item">
                                    <a><i class="fa fa-bar-chart" aria-hidden="true"></i><span>All Reports</span></a>
                                    <ul class="nav child-nav level-1">
                                        <li><a href="{{ url('dashboard/roles') }}">Pending</a></li>
                                        <li><a href="{{ url('dashboard/permissions') }}">Delivered</a></li>
                                    </ul>
                                </li>
                            @endif

                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="content-header">
                <div class="leftside-content-header">
                    <ul class="breadcrumbs">
                        <li><i class="fa fa-home" aria-hidden="true"></i><a href="#">Dashboard</a></li>
                    </ul>
                </div>
            </div>
            <div class="row animated fadeInUp">
                @yield('content')
            </div>
        </div>
        <a href="#" class="scroll-to-top"><i class="fa fa-angle-double-up"></i></a>
    </div>
</div>
<script src="{{ asset('public/js/all.js') }}" type="text/javascript"></script>
<script src="{{ asset('public/js/toaster.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('public/plugins/angular/angular.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('public/js/controller.js') }}" type="text/javascript"></script>
<script src="{{ asset('public/js/datetimepicker.js') }}" type="text/javascript"></script>

<script src="{{ asset('public/plugins/select2/js/select2.full.min.js') }}" type="text/javascript"></script>

<script src="{{ asset('public/plugins/bootstrap-fileinput/js/fileinput.min.js') }}" type="text/javascript"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/js/bootstrap-editable.min.js"></script>

<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js">
</script>
<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.2.4/js/dataTables.buttons.min.js">
</script>
<script type="text/javascript" language="javascript" src="//cdn.datatables.net/buttons/1.2.4/js/buttons.flash.min.js">
</script>
<script type="text/javascript" language="javascript" src="//cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js">
</script>
<script type="text/javascript" language="javascript" src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.24/build/pdfmake.min.js">
</script>
<script type="text/javascript" language="javascript" src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.24/build/vfs_fonts.js">
</script>
<script type="text/javascript" language="javascript" src="//cdn.datatables.net/buttons/1.2.4/js/buttons.html5.min.js">
</script>
<script type="text/javascript" language="javascript" src="//cdn.datatables.net/buttons/1.2.4/js/buttons.print.min.js">
</script>
<script>
$(document).ready(function()  {
/*
    $('.default_datetimepicker').datetimepicker();*/

    $.ajaxSetup({
        headers: {
            'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $('#user_reg_btn').click(function(){
        user_type = $('#user_reg_btn').attr('user_type');
        formData = new FormData($("#userRegistrationForm")[0]);
        $.ajax({
            url: "{{ url('registerUser') }}",
            method: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
                $('.success_div').css('display', 'block');
                $('#success-modal').modal('toggle');
                toastr.warning('User has been created successfully!', 'Notification')
                toastr.options.closeButton = true;
                window.location.href = app.host + 'dashboard/'+user_type+'/list';
            }
        }).fail(function(result){
            console.log(result)
        });
    });
    $('#same_add_chk').click(function(){
        var present_address = $('#present_address').val();
        if($('#same_add_chk').prop('checked'))
        {
            $('#permanent_address').val(present_address);
        }
        else
        {
            $('#permanent_address').val('');
        }
    })
    $('#sender_input').change(function(){console.log('dd')
        formData = new FormData($("#userRegistrationForm")[0]);
        $.ajax({
            url: "{{ url('filterSearchOrder') }}",
            method: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
                $('#modalSlideUp').modal('toggle');
                console.log(result)
            }
        }).fail(function(result){
            console.log(result)
        });
    });
    $('#user_id').change(function(){
        user_id = $('#user_id').val();
        formData = new FormData($("#OrderRequestForm")[0]);
        $.ajax({
            url: "{{ url('fetchUserDetails') }}/"+user_id,
            method: "GET",
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
                console.log(result)
                //window.location.href = app.host + 'dashboard/order/'+order_id;
            }
        }).fail(function(result){
            console.log(result)
        });
    });

    $('#delivery_type').change(function(){
        val = $('#delivery_type').val();
        if(val == 'regular')
        {
            $('#regular').css('display', 'block')
            $('#express').css('display', 'none')
        }
        else if(val == 'express')
        {
            $('#express').css('display', 'block')
            $('#regular').css('display', 'none')
        }
    })

    $('#sender_id').change(function(){
        val = $('#sender_id').val();
        index = val.indexOf('-');
        account_type = val.substr(index+1);
    })
    $('#assign_courier_btn').click(function(){
        var order_id = $('#select_location').attr('order_id');
        var location_id = $('#select_location').val();
        var courier_id = $('#select_courier').val();
        $.ajax({
            url: "{{ url('assignCourier') }}/"+order_id+'/'+courier_id+'/'+location_id,
            method: "GET",
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
                console.log(result)
                window.location.href = app.host + 'dashboard/order/'+order_id;
            }
        }).fail(function(result){
            console.log(result)
        });
    });
    $('#select_location').change(function(){
        var location = $('#select_location').val();

        if(location != 0)
        {
            $.ajax({
                url: "{{ url('getLocationbasedCourier') }}/"+location,
                method: "GET",
                contentType: false,
                cache: false,
                processData:false,
                success: function(result){
                    console.log(result)
                    $('#select_courier').html(result);
                    $('#select_courier').prop('disabled', false);
                }
            }).fail(function(result){
                console.log(result)
            });
        }
        else
        {
            $('#select_courier').prop('disabled', 'disabled');
        }
    });
    $('#btn-add-price-chart').click(function(){
        var route_id = $('#route_id').attr('route');
        formData = new FormData($("#addPriceChart")[0]);
        $.ajax({
            url: "{{ url('dashboard/route/addPrice') }}",
            method: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
                $('#modalSlideUp').modal('toggle');
                window.location.href = app.host + 'dashboard/routes/view/'+route_id;
            }
        }).fail(function(result){
            console.log(result)
        });
    });
    $('#generate_location_btn').click(function(){
        formData = new FormData($("#locationForm")[0]);
        $.ajax({
            url: "{{ url('dashboard/routes/add') }}",
            method: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
                $('#modalSlideUp').modal('toggle');
                window.location.href = app.host + 'dashboard/routes/all';
            }
        }).fail(function(result){
            console.log(result)
        });
    });
    $('#add_courier_btn').click(function(){
        var first_name = $('#first_name').val();
        var last_name = $('#last_name').val();
        if(first_name == "" || last_name == "")
        {
            /*$('#first_name').addClass('error_class');
             $('#last_name').addClass('error_class');
             $('#err_msg').css('display', 'block');*/
            toastr.warning('Form is incomplete!', 'Notification')
            $('#ajax_loading').css('display', 'none');
            toastr.options.closeButton = true;
            return false;
        }

        $('#ajax_loading').css('display', 'block');
        formData = new FormData($("#CourierRequestForm")[0]);
        $.ajax({
            url: "{{ url('dashboard/couriers/add') }}",
            method: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
                console.log(result)
                if(result == -1)
                {
                    toastr.warning('Email address already exists!', 'Notification');
                    $('#ajax_loading').css('display', 'none');
                    toastr.options.closeButton = true;
                    return false;
                }
                else {
                    toastr.success('Courer has been successfully added!', 'Notification')
                    toastr.options.closeButton = true;
                    window.location.href = app.host + 'dashboard/courier/'+result;
                }
            }
        }).fail(function(result){
            console.log(result)
        });
    });

    $('#change_courier_status').click(function(){
        var status = $('#change_courier_status').attr('status');
        var courier_id = $('#change_courier_status').attr('courier_id');

        $.ajax({
            url: "{{ url('changeCourierStatus') }}/"+courier_id+"/"+status,
            method: "GET",
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){

                if(result == 'Confirmed')
                {
                    toastr.success('Courer account has been activated.', 'Notification')
                    toastr.options.closeButton = true;
                    $('#change_courier_status').attr('src', 'https://cdn3.iconfinder.com/data/icons/flat-actions-icons-9/792/Tick_Mark_Dark-128.png')
                    $('#change_courier_status').attr('status', 'Confirmed');
                }
                else
                {
                    toastr.warning('Courer account has been deactivated.', 'Notification')
                    toastr.options.closeButton = true;
                    $('#change_courier_status').attr('src', 'https://cdn3.iconfinder.com/data/icons/ose/Error.png');
                    $('#change_courier_status').attr('status', 'Inactive');
                }
            }
        }).fail(function(result){
            console.log(result)
        });
    });
    $('#update_courier_btn').click(function(){
        var first_name = $('#first_name').val();
        var last_name = $('#last_name').val();
        if(first_name == "" || last_name == "")
        {
            /*$('#first_name').addClass('error_class');
             $('#last_name').addClass('error_class');
             $('#err_msg').css('display', 'block');*/
            toastr.warning('Form is incomplete!', 'Notification')
            toastr.options.closeButton = true;
            return false;
        }
        formData = new FormData($("#CourierRequestForm")[0]);
        $.ajax({
            url: "{{ url('dashboard/couriers/update') }}",
            method: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
                console.log(result)
                if(result == -1)
                {
                    toastr.warning('Email address already exists!', 'Notification')
                    toastr.options.closeButton = true;
                    return false;
                }
                else {
                    toastr.success('Courer has been successfully added!', 'Notification')
                    toastr.options.closeButton = true;
                   // window.location.href = app.host + 'dashboard/couriers/all';
                }
            }
        }).fail(function(result){
            console.log(result)
        });
    });
    $('#change_password_id').click(function() {
        if($('#new_password').val() != $('#retype_password').val())
        {
            toastr.warning('New password and retype password did not match.', 'Notification')
            toastr.options.closeButton = true;
            return false;
        }
        if($('#new_password').val().length < 6)
        {
            toastr.warning('Password should be atleast 6 characters long.', 'Notification')
            toastr.options.closeButton = true;
            return false;
        }
        formData = new FormData($("#PasswordChangeForm")[0]);
        $.ajax({
            url: "{{ url('updatePassword') }}",
            method: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData: false,
            success: function (result) {
                if(result == -1)
                {
                    toastr.warning('Please provide correct password.', 'Notification')
                    toastr.options.closeButton = true;
                }
                else
                {
                    toastr.success('Password has been successfully updated.!', 'Notification')
                    toastr.options.closeButton = true;
                    //window.location.href = app.host + 'dashboard';
                }
            }
        }).fail(function (result) {
            console.log(result)
        });
    });
    $('#edit_user').click(function(){
        formData = new FormData($("#userDetails")[0]);
        $.ajax({
            url: "{{ url('dashboard/users/update') }}",
            method: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
                console.log(result)
                $('#success_div').css('display', 'block');
                $("#success_div").delay(3000).fadeOut('slow');
                $('#failure_div').css('display', 'none');
                //window.location.href = app.host + 'dashboard/couriers/all';
            }
        }).fail(function(result){
            $('#success_div').css('display', 'none');
            $('#failure_div').css('display', 'block');
            $("#failure_div").delay(3000).fadeOut('slow');
        });
    });
    $('#doc_item_input').change(function(){
        item_id = $('#doc_item_input').val();
        if(item_id == 'Your document description')
        {
            $('#other_div').css('display', 'block')
        }
        else
        {
            $('#other_div').css('display', 'none');
        }
    })
    $.fn.editable.defaults.mode = 'inline';
    $.fn.editable.defaults.params = function (params) {
        params._token = $("meta[name=token]").attr("content");
        return params;
    };
    $('.editable_element').editable({

        type: 'text',
        url: '{{url("order/update")}}',
        title: 'Edit Status',
        placement: 'top',
        send: 'always',

    });
    /*var user_result;
    $.get("{{url("getUsersList/clients")}}", function(data, status){
        user_result = data;
        console.log(user_result)
        user_result[0].foreEach(function(item){
            console.log(item)
        })
            /!*)    [
                {value: 1, text: 'Active'},
                {value: 2, text: 'Blocked'},
                {value: 3, text: 'Deleted'}
                ]*!/
    });
    $('#user_id').editable({
        value: 2,
        source: user_result,
    });*/
    $('#sender_district').change(function(){
        var sender_district = $('#sender_district').val();

        if(sender_district != 0)
        {
            $.ajax({
                url: "{{ url('getUpazilla') }}/"+sender_district,
                method: "GET",
                contentType: false,
                cache: false,
                processData:false,
                success: function(result){;
                    $('#sender_upazilla').html(result)
                    $('#sender_upazilla').prop('disabled', false);
                }
            }).fail(function(result){
                console.log(result)
            });
        }
        else
        {
            $('#sender_upazilla').prop('disabled', 'disabled');
        }
    });
    $('#receiver_district').change(function(){
        var receiver_district = $('#receiver_district').val();

        if(receiver_district != 0)
        {
            $.ajax({
                url: "{{ url('getUpazilla') }}/"+receiver_district,
                method: "GET",
                contentType: false,
                cache: false,
                processData:false,
                success: function(result){;
                    $('#receiver_upazilla').html(result)
                    $('#receiver_upazilla').prop('disabled', false);
                }
            }).fail(function(result){
                console.log(result)
            });
        }
        else
        {
            $('#receiver_upazilla').prop('disabled', 'disabled');
        }
    });
    $('#deny_reason').change(function(){
        if($('#deny_reason').val() == 'Other')
        {
            $('#deny_reason_2').css('display', 'block');
        }
        else
        {
            $('#deny_reason_2').css('display', 'none');
        }
    })
    $('#order_order_status').change(function(){
        if($('#order_order_status').val() == 3)
        {
            $('#location_id').css('display', 'block');
        }
    });
    $('#order_status').click(function(){
        var order_id = $('#order_order_status').attr('order_id');
        var status = $('#order_order_status').val();
        var location_id = $('#location_id').val();
        if(status == -1)
        {
            return;
        }
        else
        {
            $.ajax({
                url: "{{ url('changeOrderStatus') }}/"+order_id+"/"+status+"/"+location_id,
                method: "GET",
                contentType: false,
                cache: false,
                processData:false,
                success: function(result){;
                   window.location.href = app.host + 'dashboard/order/'+order_id;
                }
            }).fail(function(result){
                console.log(result)
            });
        }
    });
    $('#responsive-table').DataTable({
        "order": [[ 0, 'desc' ]],
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    });

    $('#till_date').click(function(){
        if($('#till_date').prop('checked'))
        {

            $('#end_date').prop('disabled', 'disabled');
        }
        else{
            $('#end_date').prop('disabled', false);
        }
    })

    $('.select2js').select2();
    $('.default_datetimepicker').datetimepicker({
        allowTimes: ['09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00'],
    });
    $('.default_datetimepicker_without_time').datetimepicker({
        timepicker:false,
        format: 'Y/m/d'
    });
            $(this).change(function(){
        date = new Date($(this).val());
        day = date.getDate();
        month = date.getMonth()+1;
        year = date.getFullYear();
        if(month < 10)
        {
            month = "0"+month;
        }
        if(day < 10)
        {
            day = "0"+day;
        }
        $(this).val(year + "-" + month + "-" + day);
    });
    $(".fileinput").fileinput({'showUpload':false, 'previewFileType':'any'});

})
/* tooltip*/
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
    $(".nano").nanoScroller({ scroll: 'top' });
    $(".nano").nanoScroller({ scroll: 'bottom' });
});
</script>
</body>

<!-- Mirrored from pages.revox.io/dashboard/latest/html/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 02 Jan 2017 04:46:22 GMT -->
</html>