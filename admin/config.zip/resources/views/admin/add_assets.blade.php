@extends('layouts.admin.dashboard')

@section('content')
<style type="text/css">
.item-list-textbox {
    background-color: #fff;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;
    height: 34px;
    padding: 6px 12px;
    transition: border-color 0.15s ease-in-out 0s, box-shadow 0.15s ease-in-out 0s;
	width:65%;
}
.item-list-textbox{
	float:right;
}
.add-assets .checkbox-custom{
	width:auto;
	overflow:hidden;
}
</style>
<form class="form-stripe">
  <div class="col-md-5">
    <div class="panel  b-primary bt-sm">
      <div class="panel-header">
        <h5 class="panel-title">Courier Assets Information</h5>
      </div>
      <div class="panel-content">
        <div class="form-group">
          <label>Courier <span style="color:red">*</span></label>
          <select class="form-control"  id="this_courier_id" ng-model="cycle.courier_id">
            <option value="">Select a courier</option>
            <?php
			$i = 0;
			foreach($couriers as $courier){
				if(isCourierGotCycle($courier->id) == 0){
					$i++;
					echo "<option value=".$courier->id.">$courier->first_name $courier->last_name </option>";
				}
			}
			?>
          </select>
        </div>
        <div class="form-group">
          <label>Given Date <span style="color:red">*</span></label>
          <div class="input-group"> <span class="input-group-addon x-primary"><i class="fa fa-calendar"></i></span>
            <input class="form-control default_datetimepicker_without_time" id="this_given_date" type="text">
          </div>
        </div>
        <div class="form-group">
          <label for="textareaMaxLength" class="control-label">Comments</label>
          <textarea class="form-control" rows="3" id="textareaMaxLength" placeholder="Write a comment" maxlength="255"></textarea>
          <span class="help-block"><i class="fa fa-info-circle mr-xs"></i>Max characters set to <span class="code">255</span></span> </div>
      </div>
    </div>
  </div>
  <div class="col-md-7">
    <div class="panel b-primary bt-sm  add-assets">
      <div class="panel-header">
        <h5 class="panel-title">Given Item to Courier</h5>
      </div>
      <div class="panel-content" style="height:520px">
        <div class="form-group">
          <div class="col-sm-12">
            <div class="form-group">
              <div class="checkbox-custom">
                <input id="item_name1" name="item_name[]" value="Bycycle"  type="checkbox">
                <label class="check" for="checkboxCustom3">Bycycle</label>
                <input class="item-list-textbox" id="item_description1" name="item_description[]" placeholder="Bycycle Description" maxlength="255" type="text">
              </div>
            </div>
            <div class="form-group">
              <div class="checkbox-custom">
                <input id="item_name2" name="item_name[]" value="Mobile Printer" type="checkbox">
                <label class="check" for="checkboxCustom4">Mobile Printer</label>
                <input class="item-list-textbox" id="item_description2" name="item_description[]" placeholder="Mobile Printer Description" maxlength="255" type="text">
              </div>
            </div>
            <div class="form-group">
              <div class="checkbox-custom">
                <input id="item_name3" name="item_name[]" name="item_name[]" value="Mobile Phone" type="checkbox">
                <label class="check" for="checkboxCustom5">Mobile Phone</label>
                <input class="item-list-textbox" id="item_description3" name="item_description[]" placeholder="Mobile Phone Description" maxlength="255" type="text">
              </div>
            </div>
            <div class="form-group">
              <div class="checkbox-custom">
                <input id="item_name4" name="item_name[]" value="Mobile Accessories" type="checkbox">
                <label class="check" for="checkboxCustom6">Mobile Accessories</label>
                <input class="item-list-textbox" id="item_description4" name="item_description[]" placeholder="Mobile Accessories Description" maxlength="255" type="text">
              </div>
            </div>
            <div class="form-group">
              <div class="checkbox-custom">
                <input id="item_name5" name="item_name[]" value="Power Bank" type="checkbox">
                <label class="check" for="checkboxCustom7">Power Bank</label>
                <input class="item-list-textbox" id="item_description5" name="item_description[]" placeholder="Power Bank Description" maxlength="255" type="text">
              </div>
            </div>
            <div class="form-group">
              <div class="checkbox-custom">
                <input id="item_name6" name="item_name[]" value="Uniform" type="checkbox">
                <label class="check" for="checkboxCustom8">Uniform</label>
                <input class="item-list-textbox" id="item_description6" name="item_description[]" placeholder="Uniform Description" maxlength="255" type="text">
              </div>
            </div>
            <div class="form-group">
              <div class="checkbox-custom">
                <input id="item_name7" name="item_name[]" value="Security Money" type="checkbox">
                <label class="check" for="checkboxCustom9">Security Money</label>
                <input class="item-list-textbox" id="item_description7" name="item_description[]" placeholder="Security Money Description" maxlength="255" type="text">
              </div>
            </div>
            <div class="form-group">
              <div class="checkbox-custom">
                <input id="item_name8" name="item_name[]" value="Others" type="checkbox">
                <label class="check" for="checkboxCustom10">Others</label>
                <input class="item-list-textbox" id="item_description8" name="item_description[]" placeholder="Others Description" maxlength="255" type="text">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-3 col-sm-9">
      <button type="submit" class="btn btn-primary"> <i class="fa fa-check"></i> Add Assets Information</button>
    </div>
  </div>
</form>
@endsection