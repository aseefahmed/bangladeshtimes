@extends('layouts.admin.dashboard')

@section('content')
<div class="row">
  <div class="col-sm-3"> <a class="btn btn-wide btn-success" >Pickup Date: {{ date_format(date_create($order[0]->pickup_date), 'g:s A, dS M, Y') }}</a> </div>
  <div class="col-sm-3">

    <?php
		$date = date_create($order[0]->pickup_date);
		date_add($date, date_interval_create_from_date_string($order[0]->shipping_time.' hours'));
	?>
    <a class="btn btn-wide btn-warning" >Estimated Delivery: {{ date_format($date, 'g:s A, dS M, Y') }}</a> </div>
  <div class="col-sm-3 text-right"> <strong>Status:</strong>
    <a class="text-primary" data-toggle="modal" href="" data-target="#success-modal">
      @if($order[0]->flag == 0)
        <strong class="badge x-danger">Pending</strong>
      @elseif($order[0]->flag == 1)
        <strong class="badge x-success">Approved</strong>
      @elseif($order[0]->flag == 2)
        <strong class="badge x-warning">Picked Up</strong>
      @elseif($order[0]->flag == 3)
        <strong class="badge x-warning">Dropped Off To {{ findLocationDetails($order[0]->location_id)[0]->location_name }}</strong>
      @elseif($order[0]->flag == 4)
        <strong class="badge x-warning">Transferred To {{ findLocationDetails($order[0]->location_id)[0]->location_name }}</strong>
      @elseif($order[0]->flag == 5)
        <strong class="badge x-warning">Courier Assigned</strong>
      @elseif($order[0]->flag == 11)
        <strong class="badge x-warning">On Hold</strong>
      @elseif($order[0]->flag == 9)
        <strong class="badge x-warning">Delivered</strong>
      @elseif($order[0]->flag == 10)
        <strong class="badge x-warning">Returned</strong>
      @endif
    </a>
  </div>
  <div class="col-sm-3 text-right">

    <?php
    echo DNS1D::getBarcodeSVG($order[0]->id, "PHARMA2T",3,33,"green");
    echo "<br>";
    echo "<code>Barcode: </code><strong>".$order[0]->id."</strong>";
    ?>
  </div>


</div>
<div class="row">
  <div class="col-sm-6">
    <div class="panel">
      <div class="panel-header panel-warning">
        <h3 class="panel-title">Sender Information</h3>

      </div>
      <div class="panel-content">
        <ul class="user-contact-info ph-sm">
          <li> <b><i class="color-primary mr-sm fa fa-user"></i></b> <strong>Name:</strong> {{ $order[0]->name  }} </li>
          <li><b><i class="color-primary mr-sm fa fa-envelope"></i></b> <strong>Email:</strong> {{ $order[0]->email  }}</li>
          <li> <b><i class="color-primary mr-sm fa fa-phone"></i></b> <strong>Phone:</strong> @if(false) <a href="#" class="editable_element" id="sender_phone" data-type="text" data-pk="{{ $order[0]->id }}">{{ $order[0]->sender_phone  }}</a> @else
            
            {{ $order[0]->sender_phone  }}
            
            @endif </li>
          <li> <b><i class="color-primary mr-sm fa fa-map-marker"></i></b> <strong>Address:</strong> @if(false) <a href="#" class="editable_element" id="sender_street" data-type="text" data-pk="{{ $order[0]->id }}">{{ $order[0]->sender_street  }}</a> @else
            
            {{ $order[0]->sender_street  }}
            
            @endif </li>
          <li><b><i class="color-primary mr-sm fa fa-map-marker"></i></b> <strong>District:</strong> {{ $order[0]->sender_district  }}</li>
          <li><b><i class="color-primary mr-sm fa fa-map-marker"></i></b> <strong>Upazilla:</strong> {{ $order[0]->sender_upazilla_name  }}</li>
          <li> <b><i class="color-primary mr-sm fa fa-map-marker"></i></b> <strong>Post Code:</strong> @if(false) <a href="#" class="editable_element" id="sender_zipcode" data-type="text" data-pk="{{ $order[0]->id }}">{{ $order[0]->sender_zipcode  }}</a> @else
            
            {{ $order[0]->sender_zipcode  }}
            
            @endif </li>
        </ul>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="panel">
      <div class="panel-header  panel-warning">
        <h3 class="panel-title">Receiver Information</h3>
      </div>
      <div class="panel-content">
        <ul class="user-contact-info ph-sm">
          <li> <b><i class="color-primary mr-sm fa fa-user"></i></b> <strong>Name:</strong> @if(false) <a href="#" class="editable_element" id="reciever_name" data-type="text" data-pk="{{ $order[0]->id }}">{{ $order[0]->reciever_name  }}</a> @else
            
            {{ $order[0]->reciever_name  }}
            
            @endif </li>
          <li> <b><i class="color-primary mr-sm fa fa-envelope"></i></b> <strong>Email:</strong> @if(false) <a href="#" class="editable_element" id="reciever_email" data-type="text" data-pk="{{ $order[0]->id }}">{{ $order[0]->reciever_email  }}</a> @else
            
            {{ $order[0]->reciever_email  }}
            
            @endif </li>
          <li> <b><i class="color-primary mr-sm fa fa-phone"></i></b> <strong>Phone:</strong> @if(false) <a href="#" class="editable_element" id="reciever_phone" data-type="text" data-pk="{{ $order[0]->id }}">{{ $order[0]->reciever_phone  }}</a> @else
            
            {{ $order[0]->reciever_phone  }}
            
            @endif </li>
          <li> <b><i class="color-primary mr-sm fa fa-map-marker"></i></b> <strong>Address:</strong> @if(false) <a href="#" class="editable_element" id="reciever_street" data-type="text" data-pk="{{ $order[0]->id }}">{{ $order[0]->reciever_street  }}</a> @else
            
            {{ $order[0]->reciever_street  }}
            
            @endif </li>
          <li><b><i class="color-primary mr-sm fa fa-map-marker"></i></b> <strong>District:</strong> {{ $order[0]->receiver_district  }}</li>
          <li><b><i class="color-primary mr-sm fa fa-map-marker"></i></b> <strong>Upazilla:</strong> {{ $order[0]->receiver_upazilla  }}</li>
          <li> <b><i class="color-primary mr-sm fa fa-map-marker"></i></b> <strong>Post Code:</strong> @if(false) <a href="#" class="editable_element" id="reciever_zipcode" data-type="text" data-pk="{{ $order[0]->id }}">{{ $order[0]->reciever_zipcode  }}</a> @else
            
            {{ $order[0]->reciever_zipcode  }}
            
            @endif </li>
        </ul>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-sm-6">
    <div class="panel">
      <div class="panel-header panel-success">
        <h3 class="panel-title">Product Information</h3>
      </div>
      <div class="panel-content">
        <?php
		$items = unserialize($order[0]->shipment_info);
		$total_weight = 0;
		?>
        <div class="table-responsive">
          <form id="itemForm">
            {{ csrf_field() }}
            <input type="hidden" name="order_id" value="{{ $order[0]->id }}">
            <table class="table table-striped table-hover">
              <thead>
                <tr>
                  <th>Item Name</th>
                  <th>Quantity</th>
                  <th>Weight</th>
                </tr>
              </thead>
              <tbody>
              
              @if(count($items)>0)
              
              @foreach($items as $item)
              <tr>
                <td>{{ $item[0] }}</td>
                <td> @if(strlen($item[3]) != 0)
                  <input class="form-control " type="number" value="{{ $item[3] }}">
                  @else
                  
                  -
                  
                  @endif </td>
                <td> @if(strlen($item[2]) != 0)
                  <input class="form-control " type="number" value="{{ $item[2] }}">
                  @else
                  
                  -
                  
                  @endif </td>
              </tr>
              <?php  $total_weight += $item[2]; ?>
              @endforeach
              
              @endif
                </tbody>
              
            </table>
          </form>
          @if(Auth::user()->role == 1)
          <div class="col-sm-3">
            <input class="form-control btn btn-primary" type="submit" value="Edit">
          </div>
          @endif </div>
      </div>
    </div>
  </div>
  <div class="col-md-6 col-lg-6 pull-right">
    <div class="panel">
      <div class="panel-header panel-success">
        <h3 class="panel-title">Order Summary</h3>
      </div>
      <div class="panel-content">
        <ul class="user-contact-info ph-sm">
          @if($total_weight != 0)
          <li><b>Total Wight: </b> {{ $total_weight }} Kg</li>
          @endif
          <li><b>Total Items: </b> {{ count($items) }} Item(s)</li>
          <li><b>Payment Method: </b> {{ $order[0]->payment_method  }}</li>
          <li><b>Estimated Delimery Time </b> {{ $order[0]->shipping_time  }} Hour</li>
          <li><b>Net Cost: </b> {{ $order[0]->price  }} Tk.</li>
        </ul>
      </div>
    </div>
  </div>
  <div class="col-md-12 col-lg-12 pull-right">

    <div class="panel">
      <div class="panel-header panel-success">
        <h3 class="panel-title">Order Status</h3>
      </div>
      <div class="panel-content">
        <div class="panel-group faq-accordion" id="accordion_faq"> @if(count($order_statuses) == 0)
          
          No data found.
          
          @endif
          
          @foreach($order_statuses as $status)
          
          @if($status->status_type == 0)
          <?php $class="badge badge-sm x-info"; ?>
          @elseif($status->status_type == 1)
          <?php $class="badge badge-sm x-success"; ?>
          @elseif($status->status_type == 3)
          <?php $class="badge badge-sm x-warning"; ?>
          @elseif($status->status_type == 4)
          <?php $class="badge badge-sm x-danger"; ?>
          @endif
          <div class="panel panel-accordion">
            <div class="panel-header bg-scale-0"> <a class="panel-title" data-toggle="collapse" data-parent="#accordion_faq" href="#q1"> <span class="color-primary text-bold"><span class="{{ $class }}">{{ date_format(date_create($status->created_at), 'Y-m-d H:i:s') }}</span> {{ $status->status_title }} </a> </div>
          </div>
          @endforeach </div>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-sm-6">
    <div class="panel">
      <div class="panel-header  panel-info">
        <h3 class="panel-title">Location map View</h3>
      </div>
      <div class="panel-content">         
        
        <div id="map"></div>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="panel">
      <div class="panel-header  panel-info">
        <h3 class="panel-title">Distance and Driving Instruction</h3>
      </div>
      <div class="panel-content">
        <div id="right-panel">
          <p><strong>Total Distance: <span id="total"></span></strong></p>
        </div>
      </div>
    </div>
  </div>
</div>
<style>
#map {
	height:400px;
  }
</style>
<script>

      function initMap() {

        var map = new google.maps.Map(document.getElementById('map'), {

          zoom: 6,

          center: {lat: 23.7561, lng: 90.3872}  // Bangladesh.

        });



        var directionsService = new google.maps.DirectionsService;

        var directionsDisplay = new google.maps.DirectionsRenderer({

          draggable: true,

          map: map,

          panel: document.getElementById('right-panel')

        });



        directionsDisplay.addListener('directions_changed', function() {

          computeTotalDistance(directionsDisplay.getDirections());

        });



        displayRoute('{{ $order[0]->sender_street }} {{ $order[0]->sender_upazilla_name }} {{ $order[0]->sender_district }}', '{{ $order[0]->reciever_street  }}, {{ $order[0]->receiver_upazilla }} {{ $order[0]->receiver_district }}', directionsService, directionsDisplay);

      }



      function displayRoute(origin, destination, service, display) {

        service.route({

          origin: origin,

          destination: destination,

          /*waypoints: [{location: 'Adelaide, SA'}, {location: 'Broken Hill, NSW'}],*/

          travelMode: 'DRIVING',

          avoidTolls: true

        }, function(response, status) {

          if (status === 'OK') {

            display.setDirections(response);

          } else {

            alert('Could not display directions due to: ' + status);

          }

        });

      }



      function computeTotalDistance(result) {

        var total = 0;

        var myroute = result.routes[0];

        for (var i = 0; i < myroute.legs.length; i++) {

          total += myroute.legs[i].distance.value;

        }

        total = total / 1000;

        document.getElementById('total').innerHTML = total + ' km';

      }

    </script> 
<script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCQAuKSPQX1pwWUMf9nZF5xBEoESF41_WQ&callback=initMap">
    </script>
<div class="modal fade" id="success-modal" tabindex="-1" role="dialog" aria-labelledby="modal-success-label" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header state modal-success">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="modal-success-label"><i class="fa fa-anchor"></i>Change Order Status</h4>
      </div>
      <div class="modal-body">
        <form role="form" name="userRegistrationForm" id="userRegistrationForm" novalidate>
          {{ csrf_field() }}
          <div class="form-group-attached">
            <div class="row">
              <div class="col-sm-6">
                <div class="form-group form-group-default">
                  <label>Status<span style="color:red">*</span></label>
                  <select class="form-control" id="order_order_status" order_id="{{ $order[0]->id }}">
                    <option value="-1">Select Order Status</option>
                    @if(Auth::user()->role == 1)
                      <option value="1">Approved</option>
                    @endif
                    <option value="2">Picked Up</option>
                    <option value="3">Dropped Of</option>
                    <option value="4">Transferred</option>
                    <option value="11">On Hold</option>
                    <option value="9">Delivered</option>
                    <option value="10">Returned</option>
                  </select>
                  <select class="form-control" id="location_id" order_id="{{ $order[0]->id }}" style="display: none;">
                    <option value="0">Select Branch/Hub</option>

                    @foreach($locations as $location)
                      <option value="{{ $location->id }}">{{ $location->location_name }}</option>
                    @endforeach
                  </select>

                </div>
              </div>
            </div>
          </div>
        </form>
      </div>

      <div class="modal-footer"> <a type="button" class="btn btn-success"  id="order_status">Ok</a> <a type="button" class="btn btn-default" data-dismiss="modal">Close</a> </div>
    </div>
  </div>
</div>
@endsection